(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.Person','java.util.Collections','com.example.lambda.ComparatorTest$1','com.example.lambda.ComparatorTest$lambda1','com.example.lambda.ComparatorTest$lambda2']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ComparatorTest");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var personList = (I$[1]||$incl$(1)).createShortList();
System.out.println$S("=== Sorted Asc SurName ===");
(I$[2]||$incl$(2)).sort$java_util_List$java_util_Comparator(personList, ((
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['compare$com_example_lambda_Person$com_example_lambda_Person','compare','compare$TT$TT'], function (p1, p2) {
return p1.getSurName().compareTo$S(p2.getSurName());
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null])));
for (var p, $p = personList.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
p.printName();
}
System.out.println$S("=== Sorted Asc SurName ===");
(I$[2]||$incl$(2)).sort$java_util_List$java_util_Comparator(personList, ((
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['compare'], function (p1, p2) {
return p1.getSurName().compareTo$S(p2.getSurName());
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, null])));
for (var p, $p = personList.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
p.printName();
}
System.out.println$S("=== Sorted Desc SurName ===");
(I$[2]||$incl$(2)).sort$java_util_List$java_util_Comparator(personList, ((
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['compare'], function (p1, p2) {
return p2.getSurName().compareTo$S(p1.getSurName());
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
for (var p, $p = personList.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
p.printName();
}
System.out.println$S("=== OK ===");
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:07 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
