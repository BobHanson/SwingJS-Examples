(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.Gender']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RoboContactMethods");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'callDrivers$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (p.getAge() >= 16) {
this.roboCall$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'emailDraftees$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (p.getAge() >= 18 && p.getAge() <= 25  && p.getGender() === (I$[1]||$incl$(1)).MALE  ) {
this.roboEmail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'mailPilots$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (p.getAge() >= 23 && p.getAge() <= 65 ) {
this.roboMail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'roboCall$com_example_lambda_Person', function (p) {
System.out.println$CA();
});

Clazz.newMeth(C$, 'roboEmail$com_example_lambda_Person', function (p) {
System.out.println$CA();
});

Clazz.newMeth(C$, 'roboMail$com_example_lambda_Person', function (p) {
System.out.println$CA();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
