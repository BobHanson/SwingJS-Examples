(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[];
var C$=Clazz.newClass(P$, "RoboContactLambda");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'phoneContacts$java_util_List$java_util_function_Predicate', function (pl, pred) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (pred.test(p)) {
this.roboCall$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'emailContacts$java_util_List$java_util_function_Predicate', function (pl, pred) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (pred.test(p)) {
this.roboEmail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'mailContacts$java_util_List$java_util_function_Predicate', function (pl, pred) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (pred.test(p)) {
this.roboMail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'roboCall$com_example_lambda_Person', function (p) {
System.out.println$S("Calling " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getPhone() );
});

Clazz.newMeth(C$, 'roboEmail$com_example_lambda_Person', function (p) {
System.out.println$S("EMailing " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getEmail() );
});

Clazz.newMeth(C$, 'roboMail$com_example_lambda_Person', function (p) {
System.out.println$S("Mailing " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getAddress() );
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:09 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
