(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[];
var C$=Clazz.newInterface(P$, "MyTest");
})();
//Created 2018-07-20 13:49:52 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
