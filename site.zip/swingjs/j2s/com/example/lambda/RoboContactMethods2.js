(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.Gender']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RoboContactMethods2");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'callDrivers$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (this.isDriver$com_example_lambda_Person(p)) {
this.roboCall$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'emailDraftees$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (this.isDraftee$com_example_lambda_Person(p)) {
this.roboEmail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'mailPilots$java_util_List', function (pl) {
for (var p, $p = pl.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (this.isPilot$com_example_lambda_Person(p)) {
this.roboMail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'isDriver$com_example_lambda_Person', function (p) {
return p.getAge() >= 16;
});

Clazz.newMeth(C$, 'isDraftee$com_example_lambda_Person', function (p) {
return p.getAge() >= 18 && p.getAge() <= 25  && p.getGender() === (I$[1]||$incl$(1)).MALE  ;
});

Clazz.newMeth(C$, 'isPilot$com_example_lambda_Person', function (p) {
return p.getAge() >= 23 && p.getAge() <= 65 ;
});

Clazz.newMeth(C$, 'roboCall$com_example_lambda_Person', function (p) {
System.out.println$S("Calling " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getPhone() );
});

Clazz.newMeth(C$, 'roboEmail$com_example_lambda_Person', function (p) {
System.out.println$S("EMailing " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getEmail() );
});

Clazz.newMeth(C$, 'roboMail$com_example_lambda_Person', function (p) {
System.out.println$S("Mailing " + p.getGivenName() + " " + p.getSurName() + " age " + p.getAge() + " at " + p.getAddress() );
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:09 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
