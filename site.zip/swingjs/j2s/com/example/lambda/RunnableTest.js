(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.RunnableTest$1','com.example.lambda.RunnableTest$lambda1','com.example.lambda.RunnableTest$lambda2']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RunnableTest");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'test2', function () {
});

Clazz.newMeth(C$, 'main', function (args) {
System.out.println$S("=== RunnableTest ===");
var r1 = ((
(function(){var C$=Clazz.newClass(P$, "RunnableTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
System.out.println$S("Hello world one!");
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, null]));
System.out.println$S("run r1");
r1.run();
var r2 = ((
(function(){var C$=Clazz.newClass(P$, "RunnableTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, 'run', function () {
System.out.println$S("Hello world two!");
System.out.println$S("Hello world three!");
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, null]));
System.out.println$S("run r2");
r2.run();
r2=((
(function(){var C$=Clazz.newClass(P$, "RunnableTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, 'run', function () {
return System.out.println$S("Hello world 2b!");
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null]));
System.out.println$S("run r2b");
r2.run();
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
