(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.Person','com.example.lambda.Gender','com.example.lambda.RosterTest$1CheckPersonEligibleForSelectiveService','com.example.lambda.RosterTest$1','com.example.lambda.RosterTest$lambda1','com.example.lambda.RosterTest$lambda2','com.example.lambda.RosterTest$lambda3','com.example.lambda.RosterTest$lambda4','com.example.lambda.RosterTest$lambda5','com.example.lambda.RosterTest$lambda6','com.example.lambda.RosterTest$lambda7','com.example.lambda.RosterTest$lambda8','com.example.lambda.RosterTest$lambda9','com.example.lambda.RosterTest$lambda10','com.example.lambda.RosterTest$lambda11','com.example.lambda.RosterTest$lambda12','com.example.lambda.RosterTest$lambda13']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RosterTest", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'printPersonsOlderThan$java_util_List$I', function (roster, age) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (p.getAge() >= age) {
p.printPerson();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithinAgeRange$java_util_List$I$I', function (roster, low, high) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (low <= p.getAge() && p.getAge() < high ) {
p.printPerson();
}}
}, 1);

Clazz.newMeth(C$, 'printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson', function (roster, tester) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (tester.test(p)) {
p.printPerson();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithPredicate$java_util_List$java_util_function_Predicate', function (roster, tester) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (tester.test(p)) {
p.printPerson();
}}
}, 1);

Clazz.newMeth(C$, 'processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer', function (roster, tester, block) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (tester.test(p)) {
block.accept(p);
}}
}, 1);

Clazz.newMeth(C$, 'processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (roster, tester, mapper, block) {
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (tester.test(p)) {
var data = mapper.$apply(p);
block.accept(data);
}}
}, 1);

Clazz.newMeth(C$, 'processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (source, tester, mapper, block) {
for (var p, $p = source.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
if (tester.test(p)) {
var data = mapper.$apply(p);
block.accept(data);
}}
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var roster = (I$[1]||$incl$(1)).createRoster();
for (var p, $p = roster.iterator(); $p.hasNext()&&((p=($p.next())),1);) {
p.printPerson();
}
System.out.println$S("Persons older than 20:");
C$.printPersonsOlderThan$java_util_List$I(roster, 20);
System.out.println();
System.out.println$S("Persons between the ages of 14 and 30:");
C$.printPersonsWithinAgeRange$java_util_List$I$I(roster, 14, 30);
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service:");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, Clazz.new_((I$[3]||$incl$(3)), [this, null]));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (anonymous class):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (lambda expression):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, 'test', function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate parameter):");
C$.printPersonsWithPredicate$java_util_List$java_util_function_Predicate(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[6]||$incl$(6)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate and Consumer parameters):");
C$.processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[7]||$incl$(7)).$init$, [this, null])), ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['accept'], function (p) {
return p.printPerson();
});
})()
), Clazz.new_((I$[8]||$incl$(8)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate, Function, and Consumer parameters):");
C$.processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[9]||$incl$(9)).$init$, [this, null])), ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['$apply'], function (p) {
return p.getEmailAddress();
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])), ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['accept'], function (email) {
return System.out.println$S(email);
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (generic version):");
C$.processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, null])), ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['$apply'], function (p) {
return p.getEmailAddress();
});
})()
), Clazz.new_((I$[13]||$incl$(13)).$init$, [this, null])), ((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['accept'], function (email) {
return System.out.println$S(email);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
System.out.println();
System.out.println$S("Persons who are eligible for Selective Service (with bulk data operations):");
roster.stream().filter$java_util_function_Predicate(((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, null]))).map$java_util_function_Function(((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['$apply'], function (p) {
return p.getEmailAddress();
});
})()
), Clazz.new_((I$[16]||$incl$(16)).$init$, [this, null]))).forEach$java_util_function_Consumer(((
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, ['accept'], function (email) {
return System.out.println$S(email);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
}, 1);
;
(function(){var C$=Clazz.newClass(P$, "RosterTest$1CheckPersonEligibleForSelectiveService", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 2);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test'], function (p) {
return p.getGender() === (I$[2]||$incl$(2)).MALE  && p.getAge() >= 18  && p.getAge() <= 25 ;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newInterface(P$.RosterTest, "CheckPerson", function(){
});
})()
})();
//Created 2018-07-20 13:49:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
