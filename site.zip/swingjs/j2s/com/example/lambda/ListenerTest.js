(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['javax.swing.JButton','com.example.lambda.ListenerTest$1','com.example.lambda.ListenerTest$lambda1','javax.swing.JFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ListenerTest");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var i = 3;
var testButton = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Test Button"]);
testButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "ListenerTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (ae) {
System.out.println$S("Click Detected by Anon Class " + this.$finals.i);
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, {i: i}])));
testButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "ListenerTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambdaE*/
Clazz.newMeth(C$, 'actionPerformed', function (e) {
return System.out.println$S("Click Detected by Lambda Listener " + e + this.$finals.i );
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, {i: i}])));
var frame = Clazz.new_((I$[4]||$incl$(4)).c$$S,["Listener Test"]);
frame.setDefaultCloseOperation$I(3);
frame.add$java_awt_Component$O(testButton, "Center");
frame.pack();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:52 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
