(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.VecDemoFrame',['com.falstad.VecDemoFrame','.InverseRadialDouble'],['com.falstad.VecDemoFrame','.InverseRadialDipole'],['com.falstad.VecDemoFrame','.InverseSquaredRadial'],['com.falstad.VecDemoFrame','.InverseRadialQuad'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDouble'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDipole'],['com.falstad.VecDemoFrame','.InverseRotational'],['com.falstad.VecDemoFrame','.InverseSquaredRadialQuad'],['com.falstad.VecDemoFrame','.ConductingPlate'],'com.falstad.Complex',['com.falstad.VecDemoFrame','.ChargedPlate'],['com.falstad.VecDemoFrame','.ChargedPlatePair'],['com.falstad.VecDemoFrame','.ChargedPlateDipole'],['com.falstad.VecDemoFrame','.InfiniteChargedPlane'],['com.falstad.VecDemoFrame','.Cylinder'],['com.falstad.VecDemoFrame','.CylinderAndLineCharge'],['com.falstad.VecDemoFrame','.CylinderInField'],['com.falstad.VecDemoFrame','.DielectricCylinderInFieldE'],['com.falstad.VecDemoFrame','.SlottedPlane'],['com.falstad.VecDemoFrame','.PlanePair'],['com.falstad.VecDemoFrame','.InverseRotationalPotential'],['com.falstad.VecDemoFrame','.InverseRotationalDouble'],['com.falstad.VecDemoFrame','.InverseRotationalDoubleExt'],['com.falstad.VecDemoFrame','.InverseRotationalDipole'],['com.falstad.VecDemoFrame','.InverseRotationalDipoleExt'],['com.falstad.VecDemoFrame','.OneDirectionFunction'],['com.falstad.VecDemoFrame','.MovingChargeField'],['com.falstad.VecDemoFrame','.InverseSquaredRadialSphere'],['com.falstad.VecDemoFrame','.ConstRadial'],['com.falstad.VecDemoFrame','.LinearRadial'],['com.falstad.VecDemoFrame','.ConstantToYAxis'],['com.falstad.VecDemoFrame','.LinearToYAxis'],['com.falstad.VecDemoFrame','.LinearToXYAxes'],['com.falstad.VecDemoFrame','.InverseToYAxis'],['com.falstad.VecDemoFrame','.InverseSquareRotational'],['com.falstad.VecDemoFrame','.LinearRotational'],['com.falstad.VecDemoFrame','.ConstantRotational'],['com.falstad.VecDemoFrame','.FxEqualsYField'],['com.falstad.VecDemoFrame','.FxEqualsY2'],['com.falstad.VecDemoFrame','.Saddle'],['com.falstad.VecDemoFrame','.RotationalExpansion'],['com.falstad.VecDemoFrame','.Function4Field'],['com.falstad.VecDemoFrame','.Function5Field'],['com.falstad.VecDemoFrame','.Function6Field'],['com.falstad.VecDemoFrame','.Function7Field'],['com.falstad.VecDemoFrame','.PendulumPotential'],['com.falstad.VecDemoFrame','.Function8Field'],['com.falstad.VecDemoFrame','.UserDefinedPotential'],['com.falstad.VecDemoFrame','.ExprParser'],['com.falstad.VecDemoFrame','.UserDefinedFunction'],['com.falstad.VecDemoFrame','.Expr'],'java.awt.Color','java.util.Vector',['com.falstad.VecDemoFrame','.InverseRadial'],'java.util.Random',['com.falstad.VecDemoFrame','.Particle'],'com.falstad.VecDemoLayout','com.falstad.VecDemoCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','com.falstad.DecentScrollbar',['com.falstad.VecDemoFrame','.AuxBar'],'a2s.TextField','java.awt.Rectangle','java.awt.image.MemoryImageSource',['com.falstad.VecDemoFrame','.GridElement'],['com.falstad.VecDemoFrame','.FloatPair'],['com.falstad.VecDemoFrame','.DrawData'],'java.text.NumberFormat','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VecDemoCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_VecDemoFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateVecDemo$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
this.pg.updateVecDemo$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:59 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
