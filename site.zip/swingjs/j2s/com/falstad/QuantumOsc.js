(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.QuantumOscFrame','com.falstad.QuantumOscLayout','com.falstad.QuantumOscCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar',['com.falstad.QuantumOscFrame','.PhaseColor'],'java.awt.Color','java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumOscFrame','.View'],['com.falstad.QuantumOscFrame','.Phasor'],'java.awt.image.MemoryImageSource','com.falstad.Complex',['com.falstad.QuantumOscFrame','.BasisState'],['com.falstad.QuantumOscFrame','.DerivedState']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QuantumOsc", null, 'a2s.Applet');
C$.mf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
C$.mf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_QuantumOsc,[null]);
C$.mf.init();
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf=null;
});

Clazz.newMeth(C$, 'init', function () {
C$.mf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_QuantumOsc,[this]);
C$.mf.init();
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf=null;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:57 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
