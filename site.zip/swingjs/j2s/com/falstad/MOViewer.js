(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.MOViewerFrame','java.awt.Color','com.falstad.MOViewerLayout','com.falstad.MOViewerCanvas','a2s.MenuBar','a2s.Menu','javax.swing.JRadioButtonMenuItem','javax.swing.ButtonGroup','a2s.Choice','a2s.Label','a2s.Scrollbar',['com.falstad.MOViewerFrame','.PhaseColor'],'java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem',['com.falstad.MOViewerFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle','java.io.File','java.net.URL','java.util.StringTokenizer',['com.falstad.MOViewerFrame','.Orbital'],['com.falstad.MOViewerFrame','.SOrbital'],['com.falstad.MOViewerFrame','.MZeroOrbital'],['com.falstad.MOViewerFrame','.ReImOrbital']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MOViewer", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_MOViewer,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_MOViewer,[this]);
C$.ogf.init();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else C$.ogf.show();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
