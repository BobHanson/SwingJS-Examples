(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.MOViewerFrame','java.awt.Color','com.falstad.MOViewerLayout','com.falstad.MOViewerCanvas','a2s.MenuBar','a2s.Menu','javax.swing.JRadioButtonMenuItem','javax.swing.ButtonGroup','a2s.Choice','a2s.Label','a2s.Scrollbar',['com.falstad.MOViewerFrame','.PhaseColor'],'java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem',['com.falstad.MOViewerFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle','java.io.File','java.net.URL','java.util.StringTokenizer',['com.falstad.MOViewerFrame','.Orbital'],['com.falstad.MOViewerFrame','.SOrbital'],['com.falstad.MOViewerFrame','.MZeroOrbital'],['com.falstad.MOViewerFrame','.ReImOrbital']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MOViewerLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var barwidth = 0;
var i;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (d.width > barwidth) barwidth=d.width;
}}
var insets = target.insets();
var targetw = target.size().width - insets.left - insets.right ;
var cw = targetw - barwidth;
var targeth = target.size().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
cw+=insets.left;
var h = insets.top;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "a2s.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
//Created 2018-07-22 15:35:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
