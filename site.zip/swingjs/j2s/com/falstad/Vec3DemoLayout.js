(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.Vec3DemoFrame',['com.falstad.Vec3DemoFrame','.InverseSquaredRadialDouble'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialDipole'],['com.falstad.Vec3DemoFrame','.InverseRadial'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialQuad'],['com.falstad.Vec3DemoFrame','.InverseRadialDouble'],['com.falstad.Vec3DemoFrame','.InverseRadialDipole'],['com.falstad.Vec3DemoFrame','.InverseRotational'],['com.falstad.Vec3DemoFrame','.InverseRadialQuad'],['com.falstad.Vec3DemoFrame','.FiniteChargedLine'],['com.falstad.Vec3DemoFrame','.FiniteChargedLinePair'],['com.falstad.Vec3DemoFrame','.FiniteChargedLineDipole'],['com.falstad.Vec3DemoFrame','.ConductingPlate'],'com.falstad.Complex',['com.falstad.Vec3DemoFrame','.ChargedPlate'],['com.falstad.Vec3DemoFrame','.ChargedPlatePair'],['com.falstad.Vec3DemoFrame','.InfiniteChargedPlane'],['com.falstad.Vec3DemoFrame','.SphereAndPointCharge'],['com.falstad.Vec3DemoFrame','.ChargedSphereAndPointCharge'],['com.falstad.Vec3DemoFrame','.CylinderAndLineCharge'],['com.falstad.Vec3DemoFrame','.SphereInField'],['com.falstad.Vec3DemoFrame','.DielectricSphereInFieldE'],['com.falstad.Vec3DemoFrame','.DielectricSphereInFieldD'],['com.falstad.Vec3DemoFrame','.CylinderInField'],['com.falstad.Vec3DemoFrame','.DielectricCylinderInFieldE'],['com.falstad.Vec3DemoFrame','.DielectricCylinderInFieldD'],['com.falstad.Vec3DemoFrame','.DielectricBoundaryE'],['com.falstad.Vec3DemoFrame','.DielectricBoundaryD'],['com.falstad.Vec3DemoFrame','.ConductingPlane'],['com.falstad.Vec3DemoFrame','.FastChargeEField'],['com.falstad.Vec3DemoFrame','.FastChargeField'],['com.falstad.Vec3DemoFrame','.ChargedRing'],['com.falstad.Vec3DemoFrame','.PlanePair'],['com.falstad.Vec3DemoFrame','.InverseRotationalDouble'],['com.falstad.Vec3DemoFrame','.InverseRotationalDoubleExt'],['com.falstad.Vec3DemoFrame','.InverseRotationalDipole'],['com.falstad.Vec3DemoFrame','.InverseRotationalDipoleExt'],['com.falstad.Vec3DemoFrame','.OneDirectionFunction'],['com.falstad.Vec3DemoFrame','.MovingChargeField'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialSphere'],['com.falstad.Vec3DemoFrame','.MovingChargeFieldDouble'],['com.falstad.Vec3DemoFrame','.MovingChargeDipole'],['com.falstad.Vec3DemoFrame','.CurrentLoopField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsSideField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsSideOppField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsStackedField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsStackedOppField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsOpposingConcentric'],['com.falstad.Vec3DemoFrame','.SolenoidField'],['com.falstad.Vec3DemoFrame','.ChargedRingPair'],['com.falstad.Vec3DemoFrame','.ChargedRingDipole'],['com.falstad.Vec3DemoFrame','.SlottedPlane'],['com.falstad.Vec3DemoFrame','.ToroidalSolenoidField'],['com.falstad.Vec3DemoFrame','.HorseshoeElectromagnetField'],['com.falstad.Vec3DemoFrame','.SquareLoopField'],['com.falstad.Vec3DemoFrame','.RectLoopField'],['com.falstad.Vec3DemoFrame','.CornerField'],['com.falstad.Vec3DemoFrame','.MagneticSphereB'],['com.falstad.Vec3DemoFrame','.MonopoleAttempt'],['com.falstad.Vec3DemoFrame','.ConstRadial'],['com.falstad.Vec3DemoFrame','.LinearRadial'],['com.falstad.Vec3DemoFrame','.ConstantToZAxis'],['com.falstad.Vec3DemoFrame','.ConstantToXYPlane'],['com.falstad.Vec3DemoFrame','.LinearToZAxis'],['com.falstad.Vec3DemoFrame','.LinearToXYPlane'],['com.falstad.Vec3DemoFrame','.LinearToYZXZPlane'],['com.falstad.Vec3DemoFrame','.LinearToYZXZXYPlane'],['com.falstad.Vec3DemoFrame','.InverseToXYPlane'],['com.falstad.Vec3DemoFrame','.InverseSquareRotational'],['com.falstad.Vec3DemoFrame','.LinearRotational'],['com.falstad.Vec3DemoFrame','.LinearRotationalA'],['com.falstad.Vec3DemoFrame','.ConstantRotational'],['com.falstad.Vec3DemoFrame','.ConstantRotationalA'],['com.falstad.Vec3DemoFrame','.Helical'],['com.falstad.Vec3DemoFrame','.FxEqualsYField'],['com.falstad.Vec3DemoFrame','.FxEqualsY2'],['com.falstad.Vec3DemoFrame','.LinearZRotational'],['com.falstad.Vec3DemoFrame','.YzXz0Field'],['com.falstad.Vec3DemoFrame','.XY_2ZField'],['com.falstad.Vec3DemoFrame','.XY0Field'],['com.falstad.Vec3DemoFrame','.RotationalExpansion'],['com.falstad.Vec3DemoFrame','.RotationalExpansion3D'],['com.falstad.Vec3DemoFrame','.RosslerAttractor'],['com.falstad.Vec3DemoFrame','.LorenzAttractor'],['com.falstad.Vec3DemoFrame','.UserDefinedPotential'],['com.falstad.Vec3DemoFrame','.ExprParser'],['com.falstad.Vec3DemoFrame','.UserDefinedFunction'],['com.falstad.Vec3DemoFrame','.Expr'],'java.awt.Color','java.util.Vector',['com.falstad.Vec3DemoFrame','.InverseSquaredRadial'],'java.util.Random',['com.falstad.Vec3DemoFrame','.Particle'],'com.falstad.Vec3DemoLayout','com.falstad.Vec3DemoCanvas','a2s.Label','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Scrollbar',['com.falstad.Vec3DemoFrame','.AuxBar'],'a2s.TextField','java.awt.Rectangle',['com.falstad.Vec3DemoFrame','.DrawData'],['com.falstad.Vec3DemoFrame','.FieldVector'],['com.falstad.Vec3DemoFrame','.EquipPoint'],'java.net.URL',['com.falstad.Vec3DemoFrame','.MagnetState']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Vec3DemoLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var barwidth = 0;
var i;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (d.width > barwidth) barwidth=d.width;
}}
var insets = target.insets();
var targetw = target.size().width - insets.left - insets.right ;
var cw = targetw - barwidth;
var targeth = target.size().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
cw+=insets.left;
var h = insets.top;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "a2s.Scrollbar") || Clazz.instanceOf(m, "a2s.TextField") ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
//Created 2018-07-20 13:49:59 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
