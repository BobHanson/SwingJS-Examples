(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.Quantum1DCrystalFrame',['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairSetup'],['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairCoupledSetup'],['com.falstad.Quantum1DCrystalFrame','.HarmonicWellSetup'],['com.falstad.Quantum1DCrystalFrame','.CoulombWellArraySetup'],['com.falstad.Quantum1DCrystalFrame','.FreeParticleSetup'],['com.falstad.Quantum1DCrystalFrame','.SinusoidalLatticeSetup'],'java.awt.Color','java.util.Vector',['com.falstad.Quantum1DCrystalFrame','.FiniteWellSetup'],'com.falstad.Quantum1DCrystalLayout','com.falstad.Quantum1DCrystalCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','com.falstad.DecentScrollbar','java.util.Random','java.text.NumberFormat','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.Quantum1DCrystalFrame','.View'],'java.awt.Cursor',['com.falstad.Quantum1DCrystalFrame','.FFT'],'gov.nist.jama.Matrix']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Quantum1DCrystal", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.qf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.qf != null ) C$.qf.dispose();
C$.qf=null;
this.repaint();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.qf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Quantum1DCrystal,[null]);
C$.qf.init();
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.qf == null ) {
this.started=true;
C$.qf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Quantum1DCrystal,[this]);
C$.qf.init();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
var s = "Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.qf == null ) s="Applet is finished.";
 else C$.qf.show();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.qf != null ) C$.qf.dispose();
C$.qf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:14 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
