(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMWave1Frame',['com.falstad.EMWave1Frame','.IntersectingPlaneWavesSetup'],['com.falstad.EMWave1Frame','.ConductReflectSetup'],['com.falstad.EMWave1Frame','.OscDipoleSetup'],['com.falstad.EMWave1Frame','.HalfWaveAnt1Setup'],['com.falstad.EMWave1Frame','.FullWaveAnt1Setup'],['com.falstad.EMWave1Frame','.FullWaveAnt2Setup'],['com.falstad.EMWave1Frame','.OscCurrentLoop'],['com.falstad.EMWave1Frame','.BigMode01Setup'],['com.falstad.EMWave1Frame','.BigMode10Setup'],['com.falstad.EMWave1Frame','.BigMode1001Setup'],['com.falstad.EMWave1Frame','.BigMode1001iSetup'],['com.falstad.EMWave1Frame','.BigMode2Setup'],['com.falstad.EMWave1Frame','.OneByOneModesSetup'],['com.falstad.EMWave1Frame','.NByZeroModesSetup'],['com.falstad.EMWave1Frame','.NByOneModesSetup'],['com.falstad.EMWave1Frame','.NByNModesSetup'],['com.falstad.EMWave1Frame','.ZeroByNModeCombosSetup'],['com.falstad.EMWave1Frame','.OneByNModeCombosSetup'],['com.falstad.EMWave1Frame','.NByNModeCombosSetup'],['com.falstad.EMWave1Frame','.Waveguides1Setup'],['com.falstad.EMWave1Frame','.CapacitorSetup'],['com.falstad.EMWave1Frame','.ResonantCavitiesSetup'],['com.falstad.EMWave1Frame','.SingleSlitSetup'],['com.falstad.EMWave1Frame','.DoubleSlitSetup'],['com.falstad.EMWave1Frame','.TripleSlitSetup'],['com.falstad.EMWave1Frame','.ObstacleSetup'],['com.falstad.EMWave1Frame','.HalfPlaneSetup'],['com.falstad.EMWave1Frame','.LloydsMirrorSetup'],'java.util.Vector',['com.falstad.EMWave1Frame','.PlaneWaveSetup'],['com.falstad.EMWave1Frame','.OscSource'],'com.falstad.EMWave1Layout','com.falstad.EMWave1Canvas','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color',['com.falstad.EMWave1Frame','.OscElement'],'java.awt.image.MemoryImageSource']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMWave1", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.showFrame();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_EMWave1,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_EMWave1,[this]);
C$.ogf.init();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:12 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
