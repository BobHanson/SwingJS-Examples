(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.Wave2dFrame',['com.falstad.Wave2dFrame','.DoubleSlitSetup'],['com.falstad.Wave2dFrame','.GratingSetup'],['com.falstad.Wave2dFrame','.ObstacleSetup'],['com.falstad.Wave2dFrame','.ZonePlateEvenSetup'],['com.falstad.Wave2dFrame','.ZonePlateOddSetup'],['com.falstad.Wave2dFrame','.ZonePlatePhaseSetup'],['com.falstad.Wave2dFrame','.ZonePlateBlazedSetup'],['com.falstad.Wave2dFrame','.Hologram1Setup'],['com.falstad.Wave2dFrame','.Hologram2Setup'],'java.util.Vector',['com.falstad.Wave2dFrame','.SingleSlitSetup'],'com.falstad.Wave2dLayout','com.falstad.Wave2dCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color','java.awt.image.MemoryImageSource','com.falstad.FFT','java.text.NumberFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Wave2dLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.getInsets();
var targetw = target.getSize().width - insets.left - insets.right ;
var cw = (targetw * 7/10|0);
var targeth = target.getSize().height - (insets.top + insets.bottom);
target.getComponent$I(0).setLocation$I$I(insets.left, insets.top);
target.getComponent$I(0).setSize$I$I(cw, targeth);
var barwidth = targetw - cw;
cw+=insets.left;
var i;
var h = insets.top;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "a2s.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.setLocation$I$I(cw, h);
m.setSize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
//Created 2018-07-20 13:50:00 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
