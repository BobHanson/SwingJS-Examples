(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMBoxFrame','com.falstad.EMBoxLayout','com.falstad.EMBoxCanvas','a2s.Button','a2s.Checkbox','a2s.Choice',['com.falstad.EMBoxFrame','.DynControl'],'a2s.Label','a2s.Scrollbar',['com.falstad.EMBoxFrame','.Mode'],'java.util.Random',['com.falstad.EMBoxFrame','.Particle'],'java.awt.Color','java.awt.image.MemoryImageSource','java.awt.Rectangle',['com.falstad.EMBoxFrame','.DrawData'],['com.falstad.EMBoxFrame','.ModeData']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMBoxCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_EMBoxFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateEMBox$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateEMBox$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
