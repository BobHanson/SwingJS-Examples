(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.RippleFrame',['com.falstad.RippleFrame','.ImportDialogLayout'],'a2s.TextArea','a2s.Button','java.awt.Point',['com.falstad.RippleFrame','.DoubleSourceSetup'],['com.falstad.RippleFrame','.QuadrupleSourceSetup'],['com.falstad.RippleFrame','.SingleSlitSetup'],['com.falstad.RippleFrame','.DoubleSlitSetup'],['com.falstad.RippleFrame','.TripleSlitSetup'],['com.falstad.RippleFrame','.ObstacleSetup'],['com.falstad.RippleFrame','.HalfPlaneSetup'],['com.falstad.RippleFrame','.DipoleSourceSetup'],['com.falstad.RippleFrame','.LateralQuadrupoleSetup'],['com.falstad.RippleFrame','.LinearQuadrupoleSetup'],['com.falstad.RippleFrame','.HexapoleSetup'],['com.falstad.RippleFrame','.OctupoleSetup'],['com.falstad.RippleFrame','.Multi12Setup'],['com.falstad.RippleFrame','.PlaneWaveSetup'],['com.falstad.RippleFrame','.IntersectingPlaneWavesSetup'],['com.falstad.RippleFrame','.PhasedArray1Setup'],['com.falstad.RippleFrame','.PhasedArray2Setup'],['com.falstad.RippleFrame','.PhasedArray3Setup'],['com.falstad.RippleFrame','.DopplerSetup'],['com.falstad.RippleFrame','.Doppler2Setup'],['com.falstad.RippleFrame','.SonicBoomSetup'],['com.falstad.RippleFrame','.BigModeSetup'],['com.falstad.RippleFrame','.OneByOneModesSetup'],['com.falstad.RippleFrame','.OneByNModesSetup'],['com.falstad.RippleFrame','.NByNModesSetup'],['com.falstad.RippleFrame','.OneByNModeCombosSetup'],['com.falstad.RippleFrame','.NByNModeCombosSetup'],['com.falstad.RippleFrame','.ZeroByOneModesSetup'],['com.falstad.RippleFrame','.ZeroByNModesSetup'],['com.falstad.RippleFrame','.NByNAcoModesSetup'],['com.falstad.RippleFrame','.CoupledCavitiesSetup'],['com.falstad.RippleFrame','.BeatsSetup'],['com.falstad.RippleFrame','.SlowMediumSetup'],['com.falstad.RippleFrame','.RefractionSetup'],['com.falstad.RippleFrame','.InternalReflectionSetup'],['com.falstad.RippleFrame','.CoatingSetup'],['com.falstad.RippleFrame','.ZonePlateEvenSetup'],['com.falstad.RippleFrame','.ZonePlateOddSetup'],['com.falstad.RippleFrame','.CircleSetup'],['com.falstad.RippleFrame','.EllipseSetup'],['com.falstad.RippleFrame','.ResonantCavitiesSetup'],['com.falstad.RippleFrame','.ResonantCavities2Setup'],['com.falstad.RippleFrame','.RoomResonanceSetup'],['com.falstad.RippleFrame','.Waveguides1Setup'],['com.falstad.RippleFrame','.Waveguides2Setup'],['com.falstad.RippleFrame','.Waveguides3Setup'],['com.falstad.RippleFrame','.Waveguides4Setup'],['com.falstad.RippleFrame','.Waveguides5Setup'],['com.falstad.RippleFrame','.ParabolicMirror1Setup'],['com.falstad.RippleFrame','.ParabolicMirror2Setup'],['com.falstad.RippleFrame','.SoundDuctSetup'],['com.falstad.RippleFrame','.BaffledPistonSetup'],['com.falstad.RippleFrame','.LowPassFilter1Setup'],['com.falstad.RippleFrame','.LowPassFilter2Setup'],['com.falstad.RippleFrame','.HighPassFilter1Setup'],['com.falstad.RippleFrame','.HighPassFilter2Setup'],['com.falstad.RippleFrame','.BandStopFilter1Setup'],['com.falstad.RippleFrame','.BandStopFilter2Setup'],['com.falstad.RippleFrame','.BandStopFilter3Setup'],['com.falstad.RippleFrame','.PlanarConvexLensSetup'],['com.falstad.RippleFrame','.BiconvexLensSetup'],['com.falstad.RippleFrame','.PlanarConcaveSetup'],['com.falstad.RippleFrame','.CircularPrismSetup'],['com.falstad.RippleFrame','.RightAnglePrismSetup'],['com.falstad.RippleFrame','.PorroPrismSetup'],['com.falstad.RippleFrame','.ScatteringSetup'],['com.falstad.RippleFrame','.LloydsMirrorSetup'],['com.falstad.RippleFrame','.TempGradient1'],['com.falstad.RippleFrame','.TempGradient2'],['com.falstad.RippleFrame','.TempGradient3'],['com.falstad.RippleFrame','.TempGradient4'],['com.falstad.RippleFrame','.DispersionSetup'],'java.util.Vector',['com.falstad.RippleFrame','.SingleSourceSetup'],['com.falstad.RippleFrame','.OscSource'],'com.falstad.RippleLayout','com.falstad.RippleCanvas','a2s.Choice','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','java.util.Random','java.awt.image.MemoryImageSource','java.util.StringTokenizer',['com.falstad.RippleFrame','.ImportDialog']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RippleLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.getInsets();
var targetw = target.getSize().width - insets.left - insets.right ;
var cw = (targetw * 7/10|0);
if (target.getComponentCount() == 1) cw=targetw;
var targeth = target.getSize().height - (insets.top + insets.bottom);
target.getComponent$I(0).setLocation$I$I(insets.left, insets.top);
target.getComponent$I(0).setSize$I$I(cw, targeth);
var barwidth = targetw - cw;
cw+=insets.left;
var i;
var h = insets.top;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "a2s.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.setLocation$I$I(cw, h);
m.setSize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
//Created 2018-07-20 13:49:58 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
