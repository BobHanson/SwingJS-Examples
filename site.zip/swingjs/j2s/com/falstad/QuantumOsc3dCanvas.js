(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.QuantumOsc3dFrame','com.falstad.Complex','java.awt.Color','com.falstad.QuantumOsc3dLayout','com.falstad.QuantumOsc3dCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar',['com.falstad.QuantumOsc3dFrame','.PhaseColor'],'java.util.Random',['com.falstad.QuantumOsc3dFrame','.BasisState'],['com.falstad.QuantumOsc3dFrame','.AlternateBasis'],['com.falstad.QuantumOsc3dFrame','.DerivedState'],'a2s.MenuItem','a2s.CheckboxMenuItem',['com.falstad.QuantumOsc3dFrame','.TextBox'],['com.falstad.QuantumOsc3dFrame','.Phasor'],['com.falstad.QuantumOsc3dFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle',['com.falstad.QuantumOsc3dFrame','.Orbital'],['com.falstad.QuantumOsc3dFrame','.SOrbital'],['com.falstad.QuantumOsc3dFrame','.MZeroOrbital'],['com.falstad.QuantumOsc3dFrame','.PairedOrbital']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QuantumOsc3dCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_QuantumOsc3dFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateQuantumOsc3d$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateQuantumOsc3d$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:57 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
