(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.DiffractionFrame',['com.falstad.DiffractionFrame','.HalfPlaneAperture'],'java.awt.Color',['com.falstad.DiffractionFrame','.SlitAperture'],['com.falstad.DiffractionFrame','.DoubleSlitAperture'],['com.falstad.DiffractionFrame','.TripleSlitAperture'],['com.falstad.DiffractionFrame','.SquareAperture'],['com.falstad.DiffractionFrame','.RectangularAperture'],['com.falstad.DiffractionFrame','.CornerAperture'],['com.falstad.DiffractionFrame','.CrossAperture'],['com.falstad.DiffractionFrame','.RectanglesAperture'],['com.falstad.DiffractionFrame','.FrameAperture'],['com.falstad.DiffractionFrame','.PlusAperture'],['com.falstad.DiffractionFrame','.IntersectingSquaresAperture'],['com.falstad.DiffractionFrame','.DoubleCircleAperture'],['com.falstad.DiffractionFrame','.RingAperture'],['com.falstad.DiffractionFrame','.HalfCircleAperture'],'java.util.Vector',['com.falstad.DiffractionFrame','.CircularAperture'],'com.falstad.DiffractionLayout','com.falstad.DiffractionCanvas','a2s.Button','a2s.Checkbox','a2s.Choice','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.image.MemoryImageSource','java.text.NumberFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Diffraction", null, 'a2s.Applet');
C$.mf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf=null;
});

Clazz.newMeth(C$, 'init', function () {
C$.mf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Diffraction,[this]);
C$.mf.init();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.mf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Diffraction,[null]);
C$.mf.init();
}, 1);

Clazz.newMeth(C$, 'destroy', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf=null;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.mf == null ) s="Applet is finished.";
 else if (C$.mf.useFrame) C$.mf.triggerShow();
if (C$.mf == null  || C$.mf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:11 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
