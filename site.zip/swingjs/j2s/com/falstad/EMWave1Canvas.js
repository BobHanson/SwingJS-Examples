(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMWave1Frame',['com.falstad.EMWave1Frame','.IntersectingPlaneWavesSetup'],['com.falstad.EMWave1Frame','.ConductReflectSetup'],['com.falstad.EMWave1Frame','.OscDipoleSetup'],['com.falstad.EMWave1Frame','.HalfWaveAnt1Setup'],['com.falstad.EMWave1Frame','.FullWaveAnt1Setup'],['com.falstad.EMWave1Frame','.FullWaveAnt2Setup'],['com.falstad.EMWave1Frame','.OscCurrentLoop'],['com.falstad.EMWave1Frame','.BigMode01Setup'],['com.falstad.EMWave1Frame','.BigMode10Setup'],['com.falstad.EMWave1Frame','.BigMode1001Setup'],['com.falstad.EMWave1Frame','.BigMode1001iSetup'],['com.falstad.EMWave1Frame','.BigMode2Setup'],['com.falstad.EMWave1Frame','.OneByOneModesSetup'],['com.falstad.EMWave1Frame','.NByZeroModesSetup'],['com.falstad.EMWave1Frame','.NByOneModesSetup'],['com.falstad.EMWave1Frame','.NByNModesSetup'],['com.falstad.EMWave1Frame','.ZeroByNModeCombosSetup'],['com.falstad.EMWave1Frame','.OneByNModeCombosSetup'],['com.falstad.EMWave1Frame','.NByNModeCombosSetup'],['com.falstad.EMWave1Frame','.Waveguides1Setup'],['com.falstad.EMWave1Frame','.CapacitorSetup'],['com.falstad.EMWave1Frame','.ResonantCavitiesSetup'],['com.falstad.EMWave1Frame','.SingleSlitSetup'],['com.falstad.EMWave1Frame','.DoubleSlitSetup'],['com.falstad.EMWave1Frame','.TripleSlitSetup'],['com.falstad.EMWave1Frame','.ObstacleSetup'],['com.falstad.EMWave1Frame','.HalfPlaneSetup'],['com.falstad.EMWave1Frame','.LloydsMirrorSetup'],'java.util.Vector',['com.falstad.EMWave1Frame','.PlaneWaveSetup'],['com.falstad.EMWave1Frame','.OscSource'],'com.falstad.EMWave1Layout','com.falstad.EMWave1Canvas','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color',['com.falstad.EMWave1Frame','.OscElement'],'java.awt.image.MemoryImageSource']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMWave1Canvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_EMWave1Frame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateEMWave1$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateEMWave1$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
