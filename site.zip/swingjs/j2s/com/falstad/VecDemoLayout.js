(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.VecDemoFrame',['com.falstad.VecDemoFrame','.InverseRadialDouble'],['com.falstad.VecDemoFrame','.InverseRadialDipole'],['com.falstad.VecDemoFrame','.InverseSquaredRadial'],['com.falstad.VecDemoFrame','.InverseRadialQuad'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDouble'],['com.falstad.VecDemoFrame','.InverseSquaredRadialDipole'],['com.falstad.VecDemoFrame','.InverseRotational'],['com.falstad.VecDemoFrame','.InverseSquaredRadialQuad'],['com.falstad.VecDemoFrame','.ConductingPlate'],'com.falstad.Complex',['com.falstad.VecDemoFrame','.ChargedPlate'],['com.falstad.VecDemoFrame','.ChargedPlatePair'],['com.falstad.VecDemoFrame','.ChargedPlateDipole'],['com.falstad.VecDemoFrame','.InfiniteChargedPlane'],['com.falstad.VecDemoFrame','.Cylinder'],['com.falstad.VecDemoFrame','.CylinderAndLineCharge'],['com.falstad.VecDemoFrame','.CylinderInField'],['com.falstad.VecDemoFrame','.DielectricCylinderInFieldE'],['com.falstad.VecDemoFrame','.SlottedPlane'],['com.falstad.VecDemoFrame','.PlanePair'],['com.falstad.VecDemoFrame','.InverseRotationalPotential'],['com.falstad.VecDemoFrame','.InverseRotationalDouble'],['com.falstad.VecDemoFrame','.InverseRotationalDoubleExt'],['com.falstad.VecDemoFrame','.InverseRotationalDipole'],['com.falstad.VecDemoFrame','.InverseRotationalDipoleExt'],['com.falstad.VecDemoFrame','.OneDirectionFunction'],['com.falstad.VecDemoFrame','.MovingChargeField'],['com.falstad.VecDemoFrame','.InverseSquaredRadialSphere'],['com.falstad.VecDemoFrame','.ConstRadial'],['com.falstad.VecDemoFrame','.LinearRadial'],['com.falstad.VecDemoFrame','.ConstantToYAxis'],['com.falstad.VecDemoFrame','.LinearToYAxis'],['com.falstad.VecDemoFrame','.LinearToXYAxes'],['com.falstad.VecDemoFrame','.InverseToYAxis'],['com.falstad.VecDemoFrame','.InverseSquareRotational'],['com.falstad.VecDemoFrame','.LinearRotational'],['com.falstad.VecDemoFrame','.ConstantRotational'],['com.falstad.VecDemoFrame','.FxEqualsYField'],['com.falstad.VecDemoFrame','.FxEqualsY2'],['com.falstad.VecDemoFrame','.Saddle'],['com.falstad.VecDemoFrame','.RotationalExpansion'],['com.falstad.VecDemoFrame','.Function4Field'],['com.falstad.VecDemoFrame','.Function5Field'],['com.falstad.VecDemoFrame','.Function6Field'],['com.falstad.VecDemoFrame','.Function7Field'],['com.falstad.VecDemoFrame','.PendulumPotential'],['com.falstad.VecDemoFrame','.Function8Field'],['com.falstad.VecDemoFrame','.UserDefinedPotential'],['com.falstad.VecDemoFrame','.ExprParser'],['com.falstad.VecDemoFrame','.UserDefinedFunction'],['com.falstad.VecDemoFrame','.Expr'],'java.awt.Color','java.util.Vector',['com.falstad.VecDemoFrame','.InverseRadial'],'java.util.Random',['com.falstad.VecDemoFrame','.Particle'],'com.falstad.VecDemoLayout','com.falstad.VecDemoCanvas','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','com.falstad.DecentScrollbar',['com.falstad.VecDemoFrame','.AuxBar'],'a2s.TextField','java.awt.Rectangle','java.awt.image.MemoryImageSource',['com.falstad.VecDemoFrame','.GridElement'],['com.falstad.VecDemoFrame','.FloatPair'],['com.falstad.VecDemoFrame','.DrawData'],'java.text.NumberFormat','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VecDemoLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var barwidth = 0;
var i;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (d.width > barwidth) barwidth=d.width;
}}
var insets = target.insets();
var targetw = target.size().width - insets.left - insets.right ;
var cw = targetw - barwidth;
var targeth = target.size().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
cw+=insets.left;
var h = insets.top;
for (i=1; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if (Clazz.instanceOf(m, "com.falstad.DecentScrollbar") || Clazz.instanceOf(m, "a2s.TextField") ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "a2s.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}System.out.println$S("moved " + m.getClass().getName() + " to " + cw + " " + h + " " + d.height );
m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
//Created 2018-07-22 15:35:17 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
