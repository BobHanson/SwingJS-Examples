(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[['com.falstad.circuit.ImportExportDialogSwingJS','com.falstad.circuit.ImportExportClipboardDialog','com.falstad.circuit.ImportExportFileDialog']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ImportExportDialogFactory");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'Create$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
var isJS = false;
{
isJS = true;
}
if (isJS) {
return Clazz.new_((I$[1]||$incl$(1)).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else if (f.applet != null ) {
return Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else {
return Clazz.new_((I$[3]||$incl$(3)).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
}}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:50:01 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
