(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.Vec3DemoFrame',['com.falstad.Vec3DemoFrame','.InverseSquaredRadialDouble'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialDipole'],['com.falstad.Vec3DemoFrame','.InverseRadial'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialQuad'],['com.falstad.Vec3DemoFrame','.InverseRadialDouble'],['com.falstad.Vec3DemoFrame','.InverseRadialDipole'],['com.falstad.Vec3DemoFrame','.InverseRotational'],['com.falstad.Vec3DemoFrame','.InverseRadialQuad'],['com.falstad.Vec3DemoFrame','.FiniteChargedLine'],['com.falstad.Vec3DemoFrame','.FiniteChargedLinePair'],['com.falstad.Vec3DemoFrame','.FiniteChargedLineDipole'],['com.falstad.Vec3DemoFrame','.ConductingPlate'],'com.falstad.Complex',['com.falstad.Vec3DemoFrame','.ChargedPlate'],['com.falstad.Vec3DemoFrame','.ChargedPlatePair'],['com.falstad.Vec3DemoFrame','.InfiniteChargedPlane'],['com.falstad.Vec3DemoFrame','.SphereAndPointCharge'],['com.falstad.Vec3DemoFrame','.ChargedSphereAndPointCharge'],['com.falstad.Vec3DemoFrame','.CylinderAndLineCharge'],['com.falstad.Vec3DemoFrame','.SphereInField'],['com.falstad.Vec3DemoFrame','.DielectricSphereInFieldE'],['com.falstad.Vec3DemoFrame','.DielectricSphereInFieldD'],['com.falstad.Vec3DemoFrame','.CylinderInField'],['com.falstad.Vec3DemoFrame','.DielectricCylinderInFieldE'],['com.falstad.Vec3DemoFrame','.DielectricCylinderInFieldD'],['com.falstad.Vec3DemoFrame','.DielectricBoundaryE'],['com.falstad.Vec3DemoFrame','.DielectricBoundaryD'],['com.falstad.Vec3DemoFrame','.ConductingPlane'],['com.falstad.Vec3DemoFrame','.FastChargeEField'],['com.falstad.Vec3DemoFrame','.FastChargeField'],['com.falstad.Vec3DemoFrame','.ChargedRing'],['com.falstad.Vec3DemoFrame','.PlanePair'],['com.falstad.Vec3DemoFrame','.InverseRotationalDouble'],['com.falstad.Vec3DemoFrame','.InverseRotationalDoubleExt'],['com.falstad.Vec3DemoFrame','.InverseRotationalDipole'],['com.falstad.Vec3DemoFrame','.InverseRotationalDipoleExt'],['com.falstad.Vec3DemoFrame','.OneDirectionFunction'],['com.falstad.Vec3DemoFrame','.MovingChargeField'],['com.falstad.Vec3DemoFrame','.InverseSquaredRadialSphere'],['com.falstad.Vec3DemoFrame','.MovingChargeFieldDouble'],['com.falstad.Vec3DemoFrame','.MovingChargeDipole'],['com.falstad.Vec3DemoFrame','.CurrentLoopField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsSideField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsSideOppField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsStackedField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsStackedOppField'],['com.falstad.Vec3DemoFrame','.CurrentLoopsOpposingConcentric'],['com.falstad.Vec3DemoFrame','.SolenoidField'],['com.falstad.Vec3DemoFrame','.ChargedRingPair'],['com.falstad.Vec3DemoFrame','.ChargedRingDipole'],['com.falstad.Vec3DemoFrame','.SlottedPlane'],['com.falstad.Vec3DemoFrame','.ToroidalSolenoidField'],['com.falstad.Vec3DemoFrame','.HorseshoeElectromagnetField'],['com.falstad.Vec3DemoFrame','.SquareLoopField'],['com.falstad.Vec3DemoFrame','.RectLoopField'],['com.falstad.Vec3DemoFrame','.CornerField'],['com.falstad.Vec3DemoFrame','.MagneticSphereB'],['com.falstad.Vec3DemoFrame','.MonopoleAttempt'],['com.falstad.Vec3DemoFrame','.ConstRadial'],['com.falstad.Vec3DemoFrame','.LinearRadial'],['com.falstad.Vec3DemoFrame','.ConstantToZAxis'],['com.falstad.Vec3DemoFrame','.ConstantToXYPlane'],['com.falstad.Vec3DemoFrame','.LinearToZAxis'],['com.falstad.Vec3DemoFrame','.LinearToXYPlane'],['com.falstad.Vec3DemoFrame','.LinearToYZXZPlane'],['com.falstad.Vec3DemoFrame','.LinearToYZXZXYPlane'],['com.falstad.Vec3DemoFrame','.InverseToXYPlane'],['com.falstad.Vec3DemoFrame','.InverseSquareRotational'],['com.falstad.Vec3DemoFrame','.LinearRotational'],['com.falstad.Vec3DemoFrame','.LinearRotationalA'],['com.falstad.Vec3DemoFrame','.ConstantRotational'],['com.falstad.Vec3DemoFrame','.ConstantRotationalA'],['com.falstad.Vec3DemoFrame','.Helical'],['com.falstad.Vec3DemoFrame','.FxEqualsYField'],['com.falstad.Vec3DemoFrame','.FxEqualsY2'],['com.falstad.Vec3DemoFrame','.LinearZRotational'],['com.falstad.Vec3DemoFrame','.YzXz0Field'],['com.falstad.Vec3DemoFrame','.XY_2ZField'],['com.falstad.Vec3DemoFrame','.XY0Field'],['com.falstad.Vec3DemoFrame','.RotationalExpansion'],['com.falstad.Vec3DemoFrame','.RotationalExpansion3D'],['com.falstad.Vec3DemoFrame','.RosslerAttractor'],['com.falstad.Vec3DemoFrame','.LorenzAttractor'],['com.falstad.Vec3DemoFrame','.UserDefinedPotential'],['com.falstad.Vec3DemoFrame','.ExprParser'],['com.falstad.Vec3DemoFrame','.UserDefinedFunction'],['com.falstad.Vec3DemoFrame','.Expr'],'java.awt.Color','java.util.Vector',['com.falstad.Vec3DemoFrame','.InverseSquaredRadial'],'java.util.Random',['com.falstad.Vec3DemoFrame','.Particle'],'com.falstad.Vec3DemoLayout','com.falstad.Vec3DemoCanvas','a2s.Label','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Scrollbar',['com.falstad.Vec3DemoFrame','.AuxBar'],'a2s.TextField','java.awt.Rectangle',['com.falstad.Vec3DemoFrame','.DrawData'],['com.falstad.Vec3DemoFrame','.FieldVector'],['com.falstad.Vec3DemoFrame','.EquipPoint'],'java.net.URL',['com.falstad.Vec3DemoFrame','.MagnetState']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Vec3Demo", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main', function (args) {
var demo = Clazz.new_(C$);
demo.showFrame();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Vec3Demo,[this]);
C$.ogf.initFrame();
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 13:49:59 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
