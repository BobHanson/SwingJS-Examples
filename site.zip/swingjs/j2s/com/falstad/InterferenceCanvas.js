(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.InterferenceFrame','java.text.NumberFormat','com.falstad.InterferenceLayout','com.falstad.InterferenceCanvas','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "InterferenceCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_InterferenceFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateInterference$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateInterference$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 15:35:13 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
