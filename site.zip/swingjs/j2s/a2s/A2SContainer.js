(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newInterface(P$, "A2SContainer");
})();
//Created 2018-07-20 09:57:22 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
