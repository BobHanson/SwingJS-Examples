(function(){var P$=Clazz.newPackage("a2s"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Dialog", null, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$a2s_Frame$S$Z', function (c, title, isModal) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[c, title, isModal]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
