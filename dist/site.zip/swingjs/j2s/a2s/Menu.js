(function(){var P$=Clazz.newPackage("a2s"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Menu", null, 'javax.swing.JMenu');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S', function (title) {
;C$.superclazz.c$$S.apply(this,[title]);C$.$init$.apply(this);
title=null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var s=null;
}, 1);

Clazz.newMeth(C$, 'countItems$', function () {
return C$.superclazz.prototype.getComponentCount$.apply(this, []);
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
