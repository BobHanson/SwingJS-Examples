(function(){var P$=Clazz.newPackage("a2s"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Util");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'drawString$java_awt_Graphics$S$I$I', function (g, text, x, y) {
{
g.drawStringUnique(text, x, y);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
