(function(){var P$=Clazz.newPackage("a2s"),I$=[[0,'a2s.A2SEvent']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "A2SListener", null, null, ['java.awt.event.AdjustmentListener', 'java.awt.event.ActionListener', 'java.awt.event.KeyListener', 'java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$, 'adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
Clazz.new_($I$(1,1).c$$java_awt_AWTEvent,[e]).run$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
