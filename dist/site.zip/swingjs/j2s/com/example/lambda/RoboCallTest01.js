(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','com.example.lambda.RoboContactMethods']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RoboCallTest01");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var pl=$I$(1).createShortList$();
var robo=Clazz.new_($I$(2));
System.out.println$S("\n==== Test 01 ====");
System.out.println$S("\n=== Calling all Drivers ===");
robo.callDrivers$java_util_List(pl);
System.out.println$S("\n=== Emailing all Draftees ===");
robo.emailDraftees$java_util_List(pl);
System.out.println$S("\n=== Mail all Pilots ===");
robo.mailPilots$java_util_List(pl);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
