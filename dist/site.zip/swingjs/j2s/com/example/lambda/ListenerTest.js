(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'javax.swing.JButton','javax.swing.JFrame']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ListenerTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var i=3;
var testButton=Clazz.new_($I$(1,1).c$$S,["Test Button"]);
testButton.addActionListener$java_awt_event_ActionListener(((P$.ListenerTest$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ListenerTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (ae) {
System.out.println$S("Click Detected by Anon Class " + this.$finals$.i);
});
})()
), Clazz.new_(P$.ListenerTest$1.$init$,[this, {i:i}])));
testButton.addActionListener$java_awt_event_ActionListener(((P$.ListenerTest$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ListenerTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$O'], function (e) { return (System.out.println$S("Click Detected by Lambda Listener " + e + this.$finals$.i ));});
})()
), Clazz.new_(P$.ListenerTest$lambda1.$init$,[this, {i:i}])));
var frame=Clazz.new_($I$(2,1).c$$S,["Listener Test"]);
frame.setDefaultCloseOperation$I(3);
frame.add$java_awt_Component$O(testButton, "Center");
frame.pack$();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
