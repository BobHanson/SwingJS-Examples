(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'javax.swing.JButton','javax.swing.JFrame']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ListenerTest");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var i=3;
var testButton=Clazz.new_($I$(1).c$$S,["Test Button"]);
testButton.addActionListener$java_awt_event_ActionListener(((P$.ListenerTest$1||
(function(){var C$=Clazz.newClass(P$, "ListenerTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (ae) {
System.out.println$S("Click Detected by Anon Class " + this.$finals$.i);
});
})()
), Clazz.new_(P$.ListenerTest$1.$init$, [this, {i: i}])));
testButton.addActionListener$java_awt_event_ActionListener(((P$.ListenerTest$lambda1||
(function(){var C$=Clazz.newClass(P$, "ListenerTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, 'actionPerformed$', function (e) { return (System.out.println$S("Click Detected by Lambda Listener " + e + this.$finals$.i ));});
})()
), Clazz.new_(P$.ListenerTest$lambda1.$init$, [this, {i: i}])));
var frame=Clazz.new_($I$(2).c$$S,["Listener Test"]);
frame.setDefaultCloseOperation$I(3);
frame.add$java_awt_Component$O(testButton, "Center");
frame.pack$();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
