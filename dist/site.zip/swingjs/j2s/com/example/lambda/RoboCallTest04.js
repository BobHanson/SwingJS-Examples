(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','com.example.lambda.RoboContactLambda','com.example.lambda.Gender']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RoboCallTest04");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var pl=$I$(1).createShortList$();
var robo=Clazz.new_($I$(2));
var allDrivers=((P$.RoboCallTest04$lambda1||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest04$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getAge$() >= 16);});
})()
), Clazz.new_(P$.RoboCallTest04$lambda1.$init$, [this, null]));
var allDraftees=((P$.RoboCallTest04$lambda2||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest04$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getAge$() >= 18 && p.getAge$() <= 25  && p.getGender$() === $I$(3).MALE  );});
})()
), Clazz.new_(P$.RoboCallTest04$lambda2.$init$, [this, null]));
var allPilots=((P$.RoboCallTest04$lambda3||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest04$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getAge$() >= 23 && p.getAge$() <= 65 );});
})()
), Clazz.new_(P$.RoboCallTest04$lambda3.$init$, [this, null]));
System.out.println$S("\n==== Test 04 ====");
System.out.println$S("\n=== Calling all Drivers ===");
robo.phoneContacts$java_util_List$java_util_function_Predicate(pl, allDrivers);
System.out.println$S("\n=== Emailing all Draftees ===");
robo.emailContacts$java_util_List$java_util_function_Predicate(pl, allDraftees);
System.out.println$S("\n=== Mail all Pilots ===");
robo.mailContacts$java_util_List$java_util_function_Predicate(pl, allPilots);
System.out.println$S("\n=== Mail all Draftees ===");
robo.mailContacts$java_util_List$java_util_function_Predicate(pl, allDraftees);
System.out.println$S("\n=== Call all Pilots ===");
robo.phoneContacts$java_util_List$java_util_function_Predicate(pl, allPilots);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
