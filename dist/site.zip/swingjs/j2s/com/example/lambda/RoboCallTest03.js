(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.Person','com.example.lambda.RoboContactAnon','com.example.lambda.RoboCallTest03$1','com.example.lambda.Gender','com.example.lambda.RoboCallTest03$2','com.example.lambda.RoboCallTest03$3']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RoboCallTest03");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var pl = (I$[1]||$incl$(1)).createShortList();
var robo = Clazz.new_((I$[2]||$incl$(2)));
System.out.println$S("\u000a==== Test 03 ====");
System.out.println$S("\u000a=== Calling all Drivers ===");
robo.phoneContacts$java_util_List$com_example_lambda_MyTest(pl, ((
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test','test$TT'], function (p) {
return p.getAge() >= 16;
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null])));
System.out.println$S("\u000a=== Emailing all Draftees ===");
robo.emailContacts$java_util_List$com_example_lambda_MyTest(pl, ((
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test','test$TT'], function (p) {
return p.getAge() >= 18 && p.getAge() <= 25  && p.getGender() === (I$[4]||$incl$(4)).MALE  ;
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
System.out.println$S("\u000a=== Mail all Pilots ===");
robo.mailContacts$java_util_List$com_example_lambda_MyTest(pl, ((
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test','test$TT'], function (p) {
return p.getAge() >= 23 && p.getAge() <= 65 ;
});
})()
), Clazz.new_((I$[6]||$incl$(6)).$init$, [this, null])));
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:28 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
