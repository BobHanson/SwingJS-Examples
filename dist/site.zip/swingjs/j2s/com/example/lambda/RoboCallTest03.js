(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','com.example.lambda.RoboContactAnon','com.example.lambda.Gender']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RoboCallTest03");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var pl=$I$(1).createShortList$();
var robo=Clazz.new_($I$(2));
System.out.println$S("\n==== Test 03 ====");
System.out.println$S("\n=== Calling all Drivers ===");
robo.phoneContacts$java_util_List$com_example_lambda_MyTest(pl, ((P$.RoboCallTest03$1||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$','test$TT'], function (p) {
return p.getAge$() >= 16;
});
})()
), Clazz.new_(P$.RoboCallTest03$1.$init$, [this, null])));
System.out.println$S("\n=== Emailing all Draftees ===");
robo.emailContacts$java_util_List$com_example_lambda_MyTest(pl, ((P$.RoboCallTest03$2||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$','test$TT'], function (p) {
return p.getAge$() >= 18 && p.getAge$() <= 25  && p.getGender$() === $I$(3).MALE  ;
});
})()
), Clazz.new_(P$.RoboCallTest03$2.$init$, [this, null])));
System.out.println$S("\n=== Mail all Pilots ===");
robo.mailContacts$java_util_List$com_example_lambda_MyTest(pl, ((P$.RoboCallTest03$3||
(function(){var C$=Clazz.newClass(P$, "RoboCallTest03$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.example.lambda.MyTest', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$','test$TT'], function (p) {
return p.getAge$() >= 23 && p.getAge$() <= 65 ;
});
})()
), Clazz.new_(P$.RoboCallTest03$3.$init$, [this, null])));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
