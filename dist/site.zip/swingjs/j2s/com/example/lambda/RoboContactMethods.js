(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Gender']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RoboContactMethods");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'callDrivers$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 16) {
this.roboCall$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'emailDraftees$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 18 && p.getAge$() <= 25  && p.getGender$() === $I$(1).MALE  ) {
this.roboEmail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'mailPilots$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 23 && p.getAge$() <= 65 ) {
this.roboMail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'roboCall$com_example_lambda_Person', function (p) {
System.out.println$S("Calling " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getPhone$() );
});

Clazz.newMeth(C$, 'roboEmail$com_example_lambda_Person', function (p) {
System.out.println$S("EMailing " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getEmail$() );
});

Clazz.newMeth(C$, 'roboMail$com_example_lambda_Person', function (p) {
System.out.println$S("Mailing " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getAddress$() );
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
