(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Gender']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RoboContactMethods");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'callDrivers$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 16) {
this.roboCall$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'emailDraftees$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 18 && p.getAge$() <= 25  && p.getGender$() === $I$(1).MALE  ) {
this.roboEmail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'mailPilots$java_util_List', function (pl) {
for (var p, $p = pl.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= 23 && p.getAge$() <= 65 ) {
this.roboMail$com_example_lambda_Person(p);
}}
});

Clazz.newMeth(C$, 'roboCall$com_example_lambda_Person', function (p) {
System.out.println$S("Calling " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getPhone$() );
});

Clazz.newMeth(C$, 'roboEmail$com_example_lambda_Person', function (p) {
System.out.println$S("EMailing " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getEmail$() );
});

Clazz.newMeth(C$, 'roboMail$com_example_lambda_Person', function (p) {
System.out.println$S("Mailing " + p.getGivenName$() + " " + p.getSurName$() + " age " + p.getAge$() + " at " + p.getAddress$() );
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
