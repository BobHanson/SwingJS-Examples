(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','com.example.lambda.Gender']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RosterTest", function(){
Clazz.newInstance(this, arguments,0,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'printPersonsOlderThan$java_util_List$I', function (roster, age) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= age) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithinAgeRange$java_util_List$I$I', function (roster, low, high) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (low <= p.getAge$() && p.getAge$() < high ) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson', function (roster, tester) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$(p)) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithPredicate$java_util_List$java_util_function_Predicate', function (roster, tester) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$(p)) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer', function (roster, tester, block) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$(p)) {
block.accept$(p);
}}
}, 1);

Clazz.newMeth(C$, 'processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (roster, tester, mapper, block) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$(p)) {
var data=mapper.apply$(p);
block.accept$(data);
}}
}, 1);

Clazz.newMeth(C$, 'processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (source, tester, mapper, block) {
for (var p, $p = source.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$(p)) {
var data=mapper.apply$(p);
block.accept$(data);
}}
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var roster=$I$(1).createRoster$();
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
p.printPerson$();
}
System.out.println$S("Persons older than 20:");
C$.printPersonsOlderThan$java_util_List$I(roster, 20);
System.out.println$();
System.out.println$S("Persons between the ages of 14 and 30:");
C$.printPersonsWithinAgeRange$java_util_List$I$I(roster, 14, 30);
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service:");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, Clazz.new_(P$.RosterTest$1CheckPersonEligibleForSelectiveService.$init$, [this, null]));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (anonymous class):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, ((P$.RosterTest$1||
(function(){var C$=Clazz.newClass(P$, "RosterTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$'], function (p) {
return p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 ;
});
})()
), Clazz.new_(P$.RosterTest$1.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (lambda expression):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, ((P$.RosterTest$lambda1||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, 'test$', function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda1.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate parameter):");
C$.printPersonsWithPredicate$java_util_List$java_util_function_Predicate(roster, ((P$.RosterTest$lambda2||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda2.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate and Consumer parameters):");
C$.processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer(roster, ((P$.RosterTest$lambda3||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda3.$init$, [this, null])), ((P$.RosterTest$lambda4||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$'], function (p) { return (p.printPerson$());});
})()
), Clazz.new_(P$.RosterTest$lambda4.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate, Function, and Consumer parameters):");
C$.processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, ((P$.RosterTest$lambda5||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda5.$init$, [this, null])), ((P$.RosterTest$lambda6||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda6.$init$, [this, null])), ((P$.RosterTest$lambda7||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda7.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (generic version):");
C$.processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, ((P$.RosterTest$lambda8||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda8.$init$, [this, null])), ((P$.RosterTest$lambda9||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda9.$init$, [this, null])), ((P$.RosterTest$lambda10||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda10.$init$, [this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with bulk data operations):");
roster.stream$().filter$java_util_function_Predicate(((P$.RosterTest$lambda11||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda11.$init$, [this, null]))).map$java_util_function_Function(((P$.RosterTest$lambda12||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda12.$init$, [this, null]))).forEach$java_util_function_Consumer(((P$.RosterTest$lambda13||
(function(){var C$=Clazz.newClass(P$, "RosterTest$lambda13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda13.$init$, [this, null])));
}, 1);
;
(function(){var C$=Clazz.newClass(P$, "RosterTest$1CheckPersonEligibleForSelectiveService", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 2);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$'], function (p) {
return p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 ;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newInterface(P$.RosterTest, "CheckPerson", function(){
});
})()
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:19 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
