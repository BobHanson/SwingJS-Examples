(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','com.example.lambda.Gender']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RosterTest", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['CheckPerson',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'printPersonsOlderThan$java_util_List$I', function (roster, age) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (p.getAge$() >= age) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithinAgeRange$java_util_List$I$I', function (roster, low, high) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (low <= p.getAge$() && p.getAge$() < high ) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson', function (roster, tester) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$com_example_lambda_Person(p)) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'printPersonsWithPredicate$java_util_List$java_util_function_Predicate', function (roster, tester) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$O(p)) {
p.printPerson$();
}}
}, 1);

Clazz.newMeth(C$, 'processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer', function (roster, tester, block) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$O(p)) {
block.accept$O(p);
}}
}, 1);

Clazz.newMeth(C$, 'processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (roster, tester, mapper, block) {
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$O(p)) {
var data=mapper.apply$O(p);
block.accept$O(data);
}}
}, 1);

Clazz.newMeth(C$, 'processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer', function (source, tester, mapper, block) {
for (var p, $p = source.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
if (tester.test$O(p)) {
var data=mapper.apply$O(p);
block.accept$O(data);
}}
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var roster=$I$(1).createRoster$();
for (var p, $p = roster.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
p.printPerson$();
}
System.out.println$S("Persons older than 20:");
C$.printPersonsOlderThan$java_util_List$I(roster, 20);
System.out.println$();
System.out.println$S("Persons between the ages of 14 and 30:");
C$.printPersonsWithinAgeRange$java_util_List$I$I(roster, 14, 30);
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service:");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, Clazz.new_(P$.RosterTest$1CheckPersonEligibleForSelectiveService.$init$,[this, null]));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (anonymous class):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, ((P$.RosterTest$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "RosterTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'test$com_example_lambda_Person', function (p) {
return p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 ;
});
})()
), Clazz.new_(P$.RosterTest$1.$init$,[this, null])));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (lambda expression):");
C$.printPersons$java_util_List$com_example_lambda_RosterTest_CheckPerson(roster, (P$.RosterTest$lambda1$||(P$.RosterTest$lambda1$=(((P$.RosterTest$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda1.$init$,[this, null]))))));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate parameter):");
C$.printPersonsWithPredicate$java_util_List$java_util_function_Predicate(roster, (P$.RosterTest$lambda2$||(P$.RosterTest$lambda2$=(((P$.RosterTest$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda2.$init$,[this, null]))))));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate and Consumer parameters):");
C$.processPersons$java_util_List$java_util_function_Predicate$java_util_function_Consumer(roster, (P$.RosterTest$lambda3$||(P$.RosterTest$lambda3$=(((P$.RosterTest$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda3.$init$,[this, null]))))), (P$.RosterTest$lambda4$||(P$.RosterTest$lambda4$=(((P$.RosterTest$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_example_lambda_Person','accept$O'], function (p) { return (p.printPerson$());});
})()
), Clazz.new_(P$.RosterTest$lambda4.$init$,[this, null]))))));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with Predicate, Function, and Consumer parameters):");
C$.processPersonsWithFunction$java_util_List$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, (P$.RosterTest$lambda5$||(P$.RosterTest$lambda5$=(((P$.RosterTest$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda5.$init$,[this, null]))))), (P$.RosterTest$lambda6$||(P$.RosterTest$lambda6$=(((P$.RosterTest$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_example_lambda_Person','apply$O'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda6.$init$,[this, null]))))), (P$.RosterTest$lambda7$||(P$.RosterTest$lambda7$=(((P$.RosterTest$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda7.$init$,[this, null]))))));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (generic version):");
C$.processElements$Iterable$java_util_function_Predicate$java_util_function_Function$java_util_function_Consumer(roster, (P$.RosterTest$lambda8$||(P$.RosterTest$lambda8$=(((P$.RosterTest$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda8.$init$,[this, null]))))), (P$.RosterTest$lambda9$||(P$.RosterTest$lambda9$=(((P$.RosterTest$lambda9||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_example_lambda_Person','apply$O'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda9.$init$,[this, null]))))), (P$.RosterTest$lambda10$||(P$.RosterTest$lambda10$=(((P$.RosterTest$lambda10||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda10.$init$,[this, null]))))));
System.out.println$();
System.out.println$S("Persons who are eligible for Selective Service (with bulk data operations):");
roster.stream$().filter$java_util_function_Predicate((P$.RosterTest$lambda11$||(P$.RosterTest$lambda11$=(((P$.RosterTest$lambda11||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$com_example_lambda_Person','test$O'], function (p) { return (p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 );});
})()
), Clazz.new_(P$.RosterTest$lambda11.$init$,[this, null])))))).map$java_util_function_Function((P$.RosterTest$lambda12$||(P$.RosterTest$lambda12$=(((P$.RosterTest$lambda12||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_example_lambda_Person','apply$O'], function (p) { return (p.getEmailAddress$());});
})()
), Clazz.new_(P$.RosterTest$lambda12.$init$,[this, null])))))).forEach$java_util_function_Consumer((P$.RosterTest$lambda13$||(P$.RosterTest$lambda13$=(((P$.RosterTest$lambda13||
(function(){/*m*/var C$=Clazz.newClass(P$, "RosterTest$lambda13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S','accept$O'], function (email) { return (System.out.println$S(email));});
})()
), Clazz.new_(P$.RosterTest$lambda13.$init$,[this, null]))))));
}, 1);
;
(function(){/*l*/var C$=Clazz.newClass(P$, "RosterTest$1CheckPersonEligibleForSelectiveService", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, [['com.example.lambda.RosterTest','com.example.lambda.RosterTest.CheckPerson']], 2);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'test$com_example_lambda_Person', function (p) {
return p.getGender$() === $I$(2).MALE  && p.getAge$() >= 18  && p.getAge$() <= 25 ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.RosterTest, "CheckPerson", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
