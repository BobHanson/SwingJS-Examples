(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Person','java.util.Collections']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ComparatorTest");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var personList=$I$(1).createShortList$();
System.out.println$S("=== Sorted Asc SurName ===");
$I$(2).sort$java_util_List$java_util_Comparator(personList, ((P$.ComparatorTest$1||
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['compare$com_example_lambda_Person$com_example_lambda_Person','compare$','compare$TT$TT'], function (p1, p2) {
return p1.getSurName$().compareTo$S(p2.getSurName$());
});
})()
), Clazz.new_(P$.ComparatorTest$1.$init$, [this, null])));
for (var p, $p = personList.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
p.printName$();
}
System.out.println$S("=== Sorted Asc SurName ===");
$I$(2).sort$java_util_List$java_util_Comparator(personList, ((P$.ComparatorTest$lambda1||
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$'], function (p1, p2) { return (p1.getSurName$().compareTo$S(p2.getSurName$()));});
})()
), Clazz.new_(P$.ComparatorTest$lambda1.$init$, [this, null])));
for (var p, $p = personList.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
p.printName$();
}
System.out.println$S("=== Sorted Desc SurName ===");
$I$(2).sort$java_util_List$java_util_Comparator(personList, ((P$.ComparatorTest$lambda2||
(function(){var C$=Clazz.newClass(P$, "ComparatorTest$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$'], function (p1, p2) {
return p2.getSurName$().compareTo$S(p1.getSurName$());
});
})()
), Clazz.new_(P$.ComparatorTest$lambda2.$init$, [this, null])));
for (var p, $p = personList.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
p.printName$();
}
System.out.println$S("=== OK ===");
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
