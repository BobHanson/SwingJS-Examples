(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.Gender','com.example.lambda.Person','java.util.ArrayList',['com.example.lambda.Person','.Builder']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Person", function(){
Clazz.newInstance(this, arguments,0,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.givenName=null;
this.surName=null;
this.age=0;
this.gender=null;
this.eMail=null;
this.phone=null;
this.address=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_example_lambda_Person_Builder', function (builder) {
C$.$init$.apply(this);
this.givenName=builder.givenName;
this.surName=builder.surName;
this.age=builder.age;
this.gender=builder.gender;
this.eMail=builder.eMail;
this.phone=builder.phone;
this.address=builder.address;
}, 1);

Clazz.newMeth(C$, 'getEmail$', function () {
return this.eMail;
});

Clazz.newMeth(C$, 'getAddress$', function () {
return this.address;
});

Clazz.newMeth(C$, 'getPhone$', function () {
return this.phone;
});

Clazz.newMeth(C$, 'getGivenName$', function () {
return this.givenName;
});

Clazz.newMeth(C$, 'getSurName$', function () {
return this.surName;
});

Clazz.newMeth(C$, 'getAge$', function () {
return this.age;
});

Clazz.newMeth(C$, 'printPerson$', function () {
this.print$();
});

Clazz.newMeth(C$, 'print$', function () {
System.out.println$S("\nName: " + this.givenName + " " + this.surName + "\n" + "Age: " + this.age + "\n" + "Gender: " + this.gender + "\n" + "eMail: " + this.eMail + "\n" + "Phone: " + this.phone + "\n" + "Address: " + this.address + "\n" );
});

Clazz.newMeth(C$, 'printName$', function () {
System.out.println$S("Name: " + this.givenName + " " + this.surName );
});

Clazz.newMeth(C$, 'toString', function () {
return "Name: " + this.givenName + " " + this.surName + "\n" + "Age: " + this.age + "  Gender: " + this.gender + "\n" + "eMail: " + this.eMail + "\n" + "Address: " + this.address + "\n" ;
});

Clazz.newMeth(C$, 'createShortList$', function () {
var people=Clazz.new_($I$(3));
people.add$TE(Clazz.new_($I$(4)).givenName$S("Bob").surName$S("Baker").age$I(21).gender$com_example_lambda_Gender($I$(1).MALE).email$S("bob.baker@example.com").phoneNumber$S("201-121-4678").address$S("44 4th St, Smallville, KS 12333").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("Jane").surName$S("Doe").age$I(25).gender$com_example_lambda_Gender($I$(1).FEMALE).email$S("jane.doe@example.com").phoneNumber$S("202-123-4678").address$S("33 3rd St, Smallville, KS 12333").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("John").surName$S("Doe").age$I(25).gender$com_example_lambda_Gender($I$(1).MALE).email$S("john.doe@example.com").phoneNumber$S("202-123-4678").address$S("33 3rd St, Smallville, KS 12333").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("James").surName$S("Johnson").age$I(45).gender$com_example_lambda_Gender($I$(1).MALE).email$S("james.johnson@example.com").phoneNumber$S("333-456-1233").address$S("201 2nd St, New York, NY 12111").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("Joe").surName$S("Bailey").age$I(67).gender$com_example_lambda_Gender($I$(1).MALE).email$S("joebob.bailey@example.com").phoneNumber$S("112-111-1111").address$S("111 1st St, Town, CA 11111").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("Phil").surName$S("Smith").age$I(55).gender$com_example_lambda_Gender($I$(1).MALE).email$S("phil.smith@examp;e.com").phoneNumber$S("222-33-1234").address$S("22 2nd St, New Park, CO 222333").build$());
people.add$TE(Clazz.new_($I$(4)).givenName$S("Betty").surName$S("Jones").age$I(85).gender$com_example_lambda_Gender($I$(1).FEMALE).email$S("betty.jones@example.com").phoneNumber$S("211-33-1234").address$S("22 4th St, New Park, CO 222333").build$());
return people;
}, 1);

Clazz.newMeth(C$, 'createRoster$', function () {
return C$.createShortList$();
}, 1);

Clazz.newMeth(C$, 'getGender$', function () {
return this.gender;
});

Clazz.newMeth(C$, 'getEmailAddress$', function () {
return this.eMail;
});
;
(function(){var C$=Clazz.newClass(P$.Person, "Builder", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.givenName=null;
this.surName=null;
this.age=0;
this.gender=null;
this.eMail=null;
this.phone=null;
this.address=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.givenName="";
this.surName="";
this.age=0;
this.gender=$I$(1).FEMALE;
this.eMail="";
this.phone="";
this.address="";
}, 1);

Clazz.newMeth(C$, 'givenName$S', function (givenName) {
this.givenName=givenName;
return this;
});

Clazz.newMeth(C$, 'surName$S', function (surName) {
this.surName=surName;
return this;
});

Clazz.newMeth(C$, 'age$I', function (val) {
this.age=val;
return this;
});

Clazz.newMeth(C$, 'gender$com_example_lambda_Gender', function (val) {
this.gender=val;
return this;
});

Clazz.newMeth(C$, 'email$S', function (val) {
this.eMail=val;
return this;
});

Clazz.newMeth(C$, 'phoneNumber$S', function (val) {
this.phone=val;
return this;
});

Clazz.newMeth(C$, 'address$S', function (val) {
this.address=val;
return this;
});

Clazz.newMeth(C$, 'build$', function () {
return Clazz.new_($I$(2).c$$com_example_lambda_Person_Builder,[this]);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
