(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.RunnableTest','com.example.lambda.ComparatorTest','com.example.lambda.ListenerTest']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Main");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA', function (args) {
$I$(1).main$SA(args);
$I$(2).main$SA(args);
$I$(3).main$SA(args);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:53 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
