(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[[0,'com.example.lambda.RunnableTest','com.example.lambda.ComparatorTest','com.example.lambda.ListenerTest']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Main");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
$I$(1).main$SA(args);
$I$(2).main$SA(args);
$I$(3).main$SA(args);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:18 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
