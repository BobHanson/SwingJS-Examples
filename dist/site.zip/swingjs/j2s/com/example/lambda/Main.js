(function(){var P$=Clazz.newPackage("com.example.lambda"),I$=[['com.example.lambda.RunnableTest','com.example.lambda.ComparatorTest','com.example.lambda.ListenerTest']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Main");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
(I$[1]||$incl$(1)).main(args);
(I$[2]||$incl$(2)).main(args);
(I$[3]||$incl$(3)).main(args);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:28 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
