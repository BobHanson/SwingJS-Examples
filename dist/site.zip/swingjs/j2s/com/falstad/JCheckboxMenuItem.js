(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.util.ArrayList']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JCheckboxMenuItem", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.CheckboxMenuItem');
C$.$classes$=[['Group',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['group','com.falstad.JCheckboxMenuItem.Group']]]

Clazz.newMeth(C$, 'c$$S', function (s) {
;C$.superclazz.c$$S.apply(this,[s]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isSelected$', function () {
return this.getState$();
});

Clazz.newMeth(C$, 'setSelected$Z', function (b) {
if (this.group != null ) this.group.set$com_falstad_JCheckboxMenuItem(this);
this.setState$Z(b);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JCheckboxMenuItem, "Group", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.items=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['items','java.util.ArrayList']]]

Clazz.newMeth(C$, 'add$com_falstad_JCheckboxMenuItem', function (item) {
this.items.add$O(item);
item.group=this;
});

Clazz.newMeth(C$, 'set$com_falstad_JCheckboxMenuItem', function (item) {
for (var i=0; i < this.items.size$(); i++) {
if (this.items.get$I(i) !== item ) {
this.items.get$I(i).setSelected$Z(false);
}}
});

Clazz.newMeth(C$, 'getSelection$', function () {
for (var i=0; i < this.items.size$(); i++) {
if (this.items.get$I(i).isSelected$()) {
return this.items.get$I(i);
}}
return null;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:35:46 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
