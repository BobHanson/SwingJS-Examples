(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AntennaElm", null, 'com.falstad.circuit.RailElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['fmphase']]]

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
;C$.superclazz.c$$I$I$I.apply(this,[xx, yy, 0]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer', function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
this.waveform=0;
}, 1);

Clazz.newMeth(C$, 'stamp$', function () {
$I$(1).sim.stampVoltageSource$I$I$I(0, this.nodes[0], this.voltSource);
});

Clazz.newMeth(C$, 'doStep$', function () {
$I$(1).sim.updateVoltageSource$I$I$I$D(0, this.nodes[0], this.voltSource, this.getVoltage$());
});

Clazz.newMeth(C$, 'getVoltage$', function () {
this.fmphase += 2 * 3.141592653589793 * (2200 + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 13 ) * 100) * $I$(1).sim.timeStep ;
var fm=3 * Math.sin(this.fmphase);
return Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 3000 ) * (1.3 + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 12 )) * 3  + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 2710 ) * (1.3 + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 13 )) * 3  + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 2433 ) * (1.3 + Math.sin(2 * 3.141592653589793 * $I$(1).sim.t * 14 )) * 3  + fm;
});

Clazz.newMeth(C$, 'getDumpType$', function () {
return "A".$c();
});

Clazz.newMeth(C$, 'getShortcut$', function () {
return 0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
