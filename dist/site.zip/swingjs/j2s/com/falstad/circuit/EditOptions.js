(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.EditInfo','com.falstad.circuit.CircuitElm']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "EditOptions", null, null, 'com.falstad.circuit.Editable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.sim=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim', function (s) {
C$.$init$.apply(this);
this.sim=s;
}, 1);

Clazz.newMeth(C$, 'getEditInfo$I', function (n) {
if (n == 0) return Clazz.new_($I$(1).c$$S$D$D$D,["Time step size (s)", this.sim.timeStep, 0, 0]);
if (n == 1) return Clazz.new_($I$(1).c$$S$D$D$D,["Range for voltage color (V)", $I$(2).voltageRange, 0, 0]);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo', function (n, ei) {
if (n == 0 && ei.value > 0  ) this.sim.timeStep=ei.value;
if (n == 1 && ei.value > 0  ) $I$(2).voltageRange=ei.value;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:24 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
