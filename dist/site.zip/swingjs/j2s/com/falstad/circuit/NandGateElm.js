(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "NandGateElm", null, 'com.falstad.circuit.AndGateElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer', function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isInverting$', function () {
return true;
});

Clazz.newMeth(C$, 'getGateName$', function () {
return "NAND gate";
});

Clazz.newMeth(C$, 'getDumpType$', function () {
return 151;
});

Clazz.newMeth(C$, 'getShortcut$', function () {
return "@".$c();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:57 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
