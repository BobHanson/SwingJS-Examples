(function(){var P$=Clazz.newPackage("com.falstad.circuit");
/*c*/var C$=Clazz.newClass(P$, "Inductor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['inductance','compResistance','current','curSourceValue'],'I',['flags'],'O',['nodes','int[]','sim','com.falstad.circuit.CirSim']]]

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim', function (s) {
;C$.$init$.apply(this);
this.sim=s;
this.nodes=Clazz.array(Integer.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'setup$D$D$I', function (ic, cr, f) {
this.inductance=ic;
this.current=cr;
this.flags=f;
});

Clazz.newMeth(C$, 'isTrapezoidal$', function () {
return (this.flags & 2) == 0;
});

Clazz.newMeth(C$, 'reset$', function () {
this.current=0;
});

Clazz.newMeth(C$, 'stamp$I$I', function (n0, n1) {
this.nodes[0]=n0;
this.nodes[1]=n1;
if (this.isTrapezoidal$()) this.compResistance=2 * this.inductance / this.sim.timeStep;
 else this.compResistance=this.inductance / this.sim.timeStep;
this.sim.stampResistor$I$I$D(this.nodes[0], this.nodes[1], this.compResistance);
this.sim.stampRightSide$I(this.nodes[0]);
this.sim.stampRightSide$I(this.nodes[1]);
});

Clazz.newMeth(C$, 'nonLinear$', function () {
return false;
});

Clazz.newMeth(C$, 'startIteration$D', function (voltdiff) {
if (this.isTrapezoidal$()) this.curSourceValue=voltdiff / this.compResistance + this.current;
 else this.curSourceValue=this.current;
});

Clazz.newMeth(C$, 'calculateCurrent$D', function (voltdiff) {
if (this.compResistance > 0 ) this.current=voltdiff / this.compResistance + this.curSourceValue;
return this.current;
});

Clazz.newMeth(C$, 'doStep$D', function (voltdiff) {
this.sim.stampCurrentSource$I$I$D(this.nodes[0], this.nodes[1], this.curSourceValue);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
