(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,['com.falstad.circuit.ImportExportDialog','.Action'],'com.falstad.circuit.ImportExportDialogLayout','java.awt.TextArea','java.awt.Button']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImportExportClipboardDialog", null, 'java.awt.Dialog', ['com.falstad.circuit.ImportExportDialog', 'java.awt.event.ActionListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.clipboard=null;
},1);

C$.$fields$=[['O',['cframe','com.falstad.circuit.CirSim','importButton','java.awt.Button','+closeButton','text','java.awt.TextArea','$type','com.falstad.circuit.ImportExportDialog.Action','clipboard','java.awt.datatransfer.Clipboard']]]

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[f, (type === $I$(1).EXPORT ) ? "Export" : "Import", false]);C$.$init$.apply(this);
this.cframe=f;
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(2,1)));
this.add$java_awt_Component(this.text=Clazz.new_($I$(3,1).c$$S$I$I,["", 10, 60]));
this.importButton=Clazz.new_($I$(4,1).c$$S,["Import"]);
this.$type=type;
this.add$java_awt_Component(this.importButton);
this.importButton.addActionListener$java_awt_event_ActionListener(this);
this.add$java_awt_Component(this.closeButton=Clazz.new_($I$(4,1).c$$S,["Close"]));
this.closeButton.addActionListener$java_awt_event_ActionListener(this);
var x=this.cframe.main.getLocationOnScreen$();
this.resize$I$I(400, 300);
var d=this.getSize$();
this.setLocation$I$I(x.x + ((this.cframe.winSize.width - d.width)/2|0), x.y + ((this.cframe.winSize.height - d.height)/2|0));
}, 1);

Clazz.newMeth(C$, 'setDump$S', function (dump) {
this.text.setText$S(dump);
});

Clazz.newMeth(C$, 'execute$', function () {
if (this.$type === $I$(1).EXPORT ) this.text.selectAll$();
this.setVisible$Z(true);
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var i;
var src=e.getSource$();
if (src === this.importButton ) {
{
this.cframe.readSetup$S(this.text.getText$());
}}if (src === this.closeButton ) this.setVisible$Z(false);
});

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (ev) {
if (ev.id == 201) {
this.cframe.main.requestFocus$();
this.setVisible$Z(false);
this.cframe.impDialog=null;
return true;
}return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [ev]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
