(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'java.awt.Dimension']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CircuitLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1,1).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1,1).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets=target.insets$();
var targetw=target.size$().width - insets.left - insets.right ;
var cw=(targetw * 8/10|0);
var targeth=target.size$().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
var barwidth=targetw - cw;
cw+=insets.left;
var i;
var h=insets.top;
for (i=1; i < target.getComponentCount$(); i++) {
var m=target.getComponent$I(i);
if (m.isVisible$()) {
var d=m.getPreferredSize$();
if (Clazz.instanceOf(m, "java.awt.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "java.awt.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "java.awt.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
