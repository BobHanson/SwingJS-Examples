(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm','java.awt.Label','java.awt.Scrollbar','java.awt.Point','com.falstad.circuit.CirSim','com.falstad.circuit.EditInfo']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "PhotoResistorElm", null, 'com.falstad.circuit.CircuitElm');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.minresistance=0;
this.maxresistance=0;
this.resistance=0;
this.slider=null;
this.label=null;
this.ps3=null;
this.ps4=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
C$.superclazz.c$$I$I.apply(this, [xx, yy]);
C$.$init$.apply(this);
this.maxresistance=1.0E9;
this.minresistance=1000.0;
this.createSlider$();
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer', function (xa, ya, xb, yb, f, st) {
C$.superclazz.c$$I$I$I$I$I.apply(this, [xa, ya, xb, yb, f]);
C$.$init$.apply(this);
this.minresistance= new Double(st.nextToken$()).doubleValue$();
this.maxresistance= new Double(st.nextToken$()).doubleValue$();
this.createSlider$();
}, 1);

Clazz.newMeth(C$, 'nonLinear$', function () {
return true;
});

Clazz.newMeth(C$, 'getDumpType$', function () {
return 190;
});

Clazz.newMeth(C$, 'dump$', function () {
return C$.superclazz.prototype.dump$.apply(this, []) + " " + new Double(this.minresistance).toString() + " " + new Double(this.maxresistance).toString() ;
});

Clazz.newMeth(C$, 'createSlider$', function () {
$I$(1).sim.main.add$java_awt_Component(this.label=Clazz.new_($I$(2).c$$S$I,["Light Level", 1]));
var value=50;
$I$(1).sim.main.add$java_awt_Component(this.slider=Clazz.new_($I$(3).c$$I$I$I$I$I,[0, value, 1, 0, 101]));
$I$(1).sim.main.validate$();
});

Clazz.newMeth(C$, 'setPoints$', function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
this.calcLeads$I(32);
this.ps3=Clazz.new_($I$(4));
this.ps4=Clazz.new_($I$(4));
});

Clazz.newMeth(C$, 'delete$', function () {
$I$(1).sim.main.remove$java_awt_Component(this.label);
$I$(1).sim.main.remove$java_awt_Component(this.slider);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics', function (g) {
var i;
var v1=this.volts[0];
var v2=this.volts[1];
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 6);
this.draw2Leads$java_awt_Graphics(g);
this.setPowerColor$java_awt_Graphics$Z(g, true);
this.doDots$java_awt_Graphics(g);
this.drawPosts$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'calculateCurrent$', function () {
var vd=this.volts[0] - this.volts[1];
this.current=vd / this.resistance;
});

Clazz.newMeth(C$, 'startIteration$', function () {
var vd=this.volts[0] - this.volts[1];
this.resistance=this.minresistance;
});

Clazz.newMeth(C$, 'doStep$', function () {
$I$(1).sim.stampResistor$I$I$D(this.nodes[0], this.nodes[1], this.resistance);
});

Clazz.newMeth(C$, 'stamp$', function () {
$I$(1).sim.stampNonLinear$I(this.nodes[0]);
$I$(1).sim.stampNonLinear$I(this.nodes[1]);
});

Clazz.newMeth(C$, 'getInfo$SA', function (arr) {
arr[0]="spark gap";
this.getBasicInfo$SA(arr);
arr[3]="R = " + P$.CircuitElm.getUnitText$D$S(this.resistance, $I$(5).ohmString);
arr[4]="Ron = " + P$.CircuitElm.getUnitText$D$S(this.minresistance, $I$(5).ohmString);
arr[5]="Roff = " + P$.CircuitElm.getUnitText$D$S(this.maxresistance, $I$(5).ohmString);
});

Clazz.newMeth(C$, 'getEditInfo$I', function (n) {
if (n == 0) return Clazz.new_($I$(6).c$$S$D$D$D,["Min resistance (ohms)", this.minresistance, 0, 0]);
if (n == 1) return Clazz.new_($I$(6).c$$S$D$D$D,["Max resistance (ohms)", this.maxresistance, 0, 0]);
return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo', function (n, ei) {
if (ei.value > 0  && n == 0 ) this.minresistance=ei.value;
if (ei.value > 0  && n == 1 ) this.maxresistance=ei.value;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:25 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
