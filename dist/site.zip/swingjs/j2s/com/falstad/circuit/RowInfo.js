(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass(P$, "RowInfo");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nodeEq=0;
this.type=0;
this.mapCol=0;
this.mapRow=0;
this.value=0;
this.rsChanges=false;
this.lsChanges=false;
this.dropRow=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.type=0;
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:25 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
