(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'java.util.Vector','StringBuffer','com.falstad.circuit.CircuitElm','java.awt.Font','com.falstad.circuit.EditInfo','java.awt.Checkbox']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextElm", null, 'com.falstad.circuit.GraphicElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.FLAG_CENTER=1;
this.FLAG_BAR=2;
},1);

C$.$fields$=[['I',['size','FLAG_CENTER','FLAG_BAR'],'S',['text'],'O',['lines','java.util.Vector']]]

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
this.text="hello";
this.lines=Clazz.new_($I$(1,1));
this.lines.add$O(this.text);
this.size=24;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer', function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[xa, ya, xb, yb, f]);C$.$init$.apply(this);
this.size= new Integer(st.nextToken$()).intValue$();
this.text=st.nextToken$();
while (st.hasMoreTokens$())this.text += ' ' + st.nextToken$();

this.split$();
}, 1);

Clazz.newMeth(C$, 'split$', function () {
var i;
this.lines=Clazz.new_($I$(1,1));
var sb=Clazz.new_($I$(2,1).c$$S,[this.text]);
for (i=0; i < sb.length$(); i++) {
var c=sb.charAt$I(i);
if (c == "\\") {
sb.deleteCharAt$I(i);
c=sb.charAt$I(i);
if (c == "n") {
this.lines.add$O(sb.substring$I$I(0, i));
sb.delete$I$I(0, i + 1);
i=-1;
continue;
}}}
this.lines.add$O(sb.toString());
});

Clazz.newMeth(C$, 'dump$', function () {
return C$.superclazz.prototype.dump$.apply(this, []) + " " + this.size + " " + this.text ;
});

Clazz.newMeth(C$, 'getDumpType$', function () {
return "x".$c();
});

Clazz.newMeth(C$, 'drag$I$I', function (xx, yy) {
this.x=xx;
this.y=yy;
this.x2=xx + 16;
this.y2=yy;
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.needsHighlight$() ? $I$(3).selectColor : $I$(3).lightGrayColor);
var f=Clazz.new_($I$(4,1).c$$S$I$I,["SansSerif", 0, this.size]);
g.setFont$java_awt_Font(f);
var fm=g.getFontMetrics$();
var i;
var maxw=-1;
for (i=0; i != this.lines.size$(); i++) {
var w=fm.stringWidth$S((this.lines.elementAt$I(i)));
if (w > maxw) maxw=w;
}
var cury=this.y;
this.setBbox$I$I$I$I(this.x, this.y, this.x, this.y);
for (i=0; i != this.lines.size$(); i++) {
var s=(this.lines.elementAt$I(i));
if ((this.flags & 1) != 0) this.x=(($I$(3).sim.winSize.width - fm.stringWidth$S(s))/2|0);
g.drawString$S$I$I(s, this.x, cury);
if ((this.flags & 2) != 0) {
var by=cury - fm.getAscent$();
g.drawLine$I$I$I$I(this.x, by, this.x + fm.stringWidth$S(s) - 1, by);
}this.adjustBbox$I$I$I$I(this.x, cury - fm.getAscent$(), this.x + fm.stringWidth$S(s), cury + fm.getDescent$());
cury+=fm.getHeight$();
}
this.x2=this.boundingBox.x + this.boundingBox.width;
this.y2=this.boundingBox.y + this.boundingBox.height;
});

Clazz.newMeth(C$, 'getEditInfo$I', function (n) {
if (n == 0) {
var ei=Clazz.new_($I$(5,1).c$$S$D$D$D,["Text", 0, -1, -1]);
ei.text=this.text;
return ei;
}if (n == 1) return Clazz.new_($I$(5,1).c$$S$D$D$D,["Size", this.size, 5, 100]);
if (n == 2) {
var ei=Clazz.new_($I$(5,1).c$$S$D$D$D,["", 0, -1, -1]);
ei.checkbox=Clazz.new_(["Center", (this.flags & 1) != 0],$I$(6,1).c$$S$Z);
return ei;
}if (n == 3) {
var ei=Clazz.new_($I$(5,1).c$$S$D$D$D,["", 0, -1, -1]);
ei.checkbox=Clazz.new_(["Draw Bar On Top", (this.flags & 2) != 0],$I$(6,1).c$$S$Z);
return ei;
}return null;
});

Clazz.newMeth(C$, 'setEditValue$I$com_falstad_circuit_EditInfo', function (n, ei) {
if (n == 0) {
this.text=ei.textf.getText$();
this.split$();
}if (n == 1) this.size=(ei.value|0);
if (n == 3) {
if (ei.checkbox.getState$()) this.flags|=2;
 else this.flags&=~2;
}if (n == 2) {
if (ei.checkbox.getState$()) this.flags|=1;
 else this.flags&=~1;
}});

Clazz.newMeth(C$, 'isCenteredText$', function () {
return (this.flags & 1) != 0;
});

Clazz.newMeth(C$, 'getInfo$SA', function (arr) {
arr[0]=this.text;
});

Clazz.newMeth(C$, 'getShortcut$', function () {
return "t".$c();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
