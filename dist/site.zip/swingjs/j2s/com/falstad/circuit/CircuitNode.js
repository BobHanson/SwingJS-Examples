(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'java.util.Vector']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CircuitNode");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['internal'],'I',['x','y'],'O',['links','java.util.Vector']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
this.links=Clazz.new_($I$(1,1));
}, 1);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
