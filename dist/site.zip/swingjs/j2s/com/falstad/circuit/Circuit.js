(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CirSim']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Circuit", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.finished=false;
this.started=false;
},1);

C$.$fields$=[['Z',['finished','started']]
,['O',['ogf','com.falstad.circuit.CirSim']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
this.finished=true;
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
this.showFrame$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_circuit_Circuit,[null]);
C$.ogf.init$();
}, 1);

Clazz.newMeth(C$, ['showFrame$','showFrame'], function () {
if (this.finished) {
this.repaint$();
return;
}if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_circuit_Circuit,[this]);
C$.ogf.init$();
}C$.ogf.setVisible$Z(true);
this.repaint$();
});

Clazz.newMeth(C$, ['hideFrame$','hideFrame'], function () {
if (this.finished) return;
C$.ogf.setVisible$Z(false);
this.repaint$();
});

Clazz.newMeth(C$, ['toggleSwitch$I','toggleSwitch'], function (x) {
C$.ogf.toggleSwitch$I(x);
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (C$.ogf != null  && !C$.ogf.isVisible$() ) s="Applet window is hidden.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null  || this.finished ) s="Applet is finished.";
 else if (C$.ogf != null  && C$.ogf.useFrame ) C$.ogf.triggerShow$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
if (C$.ogf != null ) C$.ogf.componentResized$java_awt_event_ComponentEvent(e);
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
