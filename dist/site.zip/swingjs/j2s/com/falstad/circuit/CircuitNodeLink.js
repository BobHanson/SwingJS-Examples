(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "CircuitNodeLink");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['num'],'O',['elm','com.falstad.circuit.CircuitElm']]]

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
