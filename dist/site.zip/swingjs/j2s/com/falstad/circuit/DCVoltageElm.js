(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.VoltageElm']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DCVoltageElm", null, 'com.falstad.circuit.VoltageElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
;C$.superclazz.c$$I$I$I.apply(this,[xx, yy, 0]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getDumpClass$', function () {
return Clazz.getClass($I$(1));
});

Clazz.newMeth(C$, 'getShortcut$', function () {
return "v".$c();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
