(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,['com.falstad.circuit.ImportExportDialog','.Action'],'java.awt.TextArea']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImportExportDialogSwingJS", null, 'java.awt.Dialog', 'com.falstad.circuit.ImportExportDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['cframe','com.falstad.circuit.CirSim','text','java.awt.TextArea','$type','com.falstad.circuit.ImportExportDialog.Action']]
,['S',['lastName']]]

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
;C$.superclazz.c$$java_awt_Frame$S$Z.apply(this,[f, (type === $I$(1).EXPORT ) ? "Export" : "Import", false]);C$.$init$.apply(this);
this.cframe=f;
this.$type=type;
this.text=Clazz.new_($I$(2,1).c$$S$I$I,["", 10, 60]);
}, 1);

Clazz.newMeth(C$, 'setDump$S', function (dump) {
this.text.setText$S(dump);
});

Clazz.newMeth(C$, 'execute$', function () {
if (this.$type === $I$(1).IMPORT ) {
{
swingjs.JSToolkit.getFileFromDialog(this, "string");
}
} else {
var data=this.text.getText$();
var mimeType="text/plain";
var encoding=null;
var fileName=null;
var name=C$.lastName;
{
fileName = prompt("Enter a file name", name); fileName && swingjs.JSToolkit.saveFile(fileName, data, mimeType, encoding);
}
}this.dispose$();
return;
});

Clazz.newMeth(C$, 'handleFileLoaded$O$S', function (data, fileName) {
if (fileName == null ) return;
C$.lastName=fileName;
try {
this.cframe.readSetup$S(data);
} finally {
this.dispose$();
}
});

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (ev) {
if (ev.id == 201) {
this.cframe.main.requestFocus$();
this.setVisible$Z(false);
this.cframe.impDialog=null;
return true;
}return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [ev]);
});

C$.$static$=function(){C$.$static$=0;
C$.lastName="circuit.txt";
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
