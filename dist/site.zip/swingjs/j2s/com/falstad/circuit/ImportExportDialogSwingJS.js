(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,['com.falstad.circuit.ImportExportDialog','.Action'],'java.awt.TextArea']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ImportExportDialogSwingJS", null, 'java.awt.Dialog', 'com.falstad.circuit.ImportExportDialog');
C$.lastName=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.lastName="circuit.txt";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cframe=null;
this.text=null;
this.$type=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
C$.superclazz.c$$java_awt_Frame$S$Z.apply(this, [f, (type === $I$(1).EXPORT ) ? "Export" : "Import", false]);
C$.$init$.apply(this);
this.cframe=f;
this.$type=type;
this.text=Clazz.new_($I$(2).c$$S$I$I,["", 10, 60]);
}, 1);

Clazz.newMeth(C$, 'setDump$S', function (dump) {
this.text.setText$S(dump);
});

Clazz.newMeth(C$, 'execute$', function () {
if (this.$type === $I$(1).IMPORT ) {
{
swingjs.JSToolkit.getFileFromDialog(this, "string");
}
} else {
var data=this.text.getText$();
var mimeType="text/plain";
var encoding=null;
var fileName=null;
var name=C$.lastName;
{
fileName = prompt("Enter a file name", name); fileName && swingjs.JSToolkit.saveFile(fileName, data, mimeType, encoding);
}
}this.dispose$();
return;
});

Clazz.newMeth(C$, 'handleFileLoaded$O$S', function (data, fileName) {
if (fileName == null ) return;
C$.lastName=fileName;
try {
this.cframe.readSetup$S(data);
} finally {
this.dispose$();
}
});

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (ev) {
if (ev.id == 201) {
this.cframe.main.requestFocus$();
this.setVisible$Z(false);
this.cframe.impDialog=null;
return true;
}return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [ev]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:24 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
