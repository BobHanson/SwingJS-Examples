(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.ImportExportDialogSwingJS','com.falstad.circuit.ImportExportClipboardDialog','com.falstad.circuit.ImportExportFileDialog']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ImportExportDialogFactory");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'Create$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
var isJS=false;
{
isJS = true;
}
if (isJS) {
return Clazz.new_($I$(1).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else if (f.applet != null ) {
return Clazz.new_($I$(2).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
} else {
return Clazz.new_($I$(3).c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action,[f, type]);
}}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:24 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
