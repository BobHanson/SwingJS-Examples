(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'java.awt.FileDialog','java.awt.Frame',['com.falstad.circuit.ImportExportDialog','.Action'],'java.io.File','java.io.FileInputStream',['java.nio.channels.FileChannel','.MapMode'],'java.nio.charset.Charset','java.io.FileOutputStream']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImportExportFileDialog", null, null, 'com.falstad.circuit.ImportExportDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['cframe','com.falstad.circuit.CirSim','type','com.falstad.circuit.ImportExportDialog.Action']]
,['S',['circuitDump','directory']]]

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
;C$.$init$.apply(this);
this.type=type;
this.cframe=f;
}, 1);

Clazz.newMeth(C$, 'setDump$S', function (dump) {
C$.circuitDump=dump;
});

Clazz.newMeth(C$, 'getDump$', function () {
return C$.circuitDump;
});

Clazz.newMeth(C$, 'execute$', function () {
var fd=Clazz.new_([Clazz.new_($I$(2,1)), (this.type === $I$(3).EXPORT ) ? "Save File" : "Open File", (this.type === $I$(3).EXPORT ) ? 1 : 0],$I$(1,1).c$$java_awt_Frame$S$I);
fd.setDirectory$S(C$.directory);
fd.setVisible$Z(true);
var file=fd.getFile$();
var dir=fd.getDirectory$();
if (dir != null ) C$.directory=dir;
if (file == null ) return;
System.err.println$S(dir + $I$(4).separator + file );
if (this.type === $I$(3).EXPORT ) {
try {
C$.writeFile$S(dir + file);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
} else {
try {
var dump=C$.readFile$S(dir + file);
C$.circuitDump=dump;
this.cframe.readSetup$S(C$.circuitDump);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'readFile$S', function (path) {
var stream=null;
try {
stream=Clazz.new_([Clazz.new_($I$(4,1).c$$S,[path])],$I$(5,1).c$$java_io_File);
var fc=stream.getChannel$();
var bb=fc.map$java_nio_channels_FileChannel_MapMode$J$J($I$(6).READ_ONLY, 0, fc.size$());
return $I$(7).forName$S("UTF-8").decode$java_nio_ByteBuffer(bb).toString();
} finally {
stream.close$();
}
}, 1);

Clazz.newMeth(C$, 'writeFile$S', function (path) {
var stream=null;
try {
stream=Clazz.new_([Clazz.new_($I$(4,1).c$$S,[path])],$I$(8,1).c$$java_io_File);
var fc=stream.getChannel$();
var bb=$I$(7).forName$S("UTF-8").encode$S(C$.circuitDump);
fc.write$java_nio_ByteBuffer(bb);
} finally {
stream.close$();
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.directory=".";
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
