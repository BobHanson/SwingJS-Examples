(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[['java.awt.FileDialog','java.awt.Frame',['com.falstad.circuit.ImportExportDialog','.Action'],'java.io.File','java.io.FileInputStream',['java.nio.channels.FileChannel','.MapMode'],'java.nio.charset.Charset','java.io.FileOutputStream']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ImportExportFileDialog", null, null, 'com.falstad.circuit.ImportExportDialog');
C$.circuitDump = null;
C$.directory = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.directory = ".";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cframe = null;
this.type = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_circuit_CirSim$com_falstad_circuit_ImportExportDialog_Action', function (f, type) {
C$.$init$.apply(this);
this.type=type;
this.cframe=f;
}, 1);

Clazz.newMeth(C$, 'setDump$S', function (dump) {
C$.circuitDump=dump;
});

Clazz.newMeth(C$, 'getDump', function () {
return C$.circuitDump;
});

Clazz.newMeth(C$, 'execute', function () {
var fd = Clazz.new_((I$[1]||$incl$(1)).c$$java_awt_Frame$S$I,[Clazz.new_((I$[2]||$incl$(2))), (this.type === (I$[3]||$incl$(3)).EXPORT ) ? "Save File" : "Open File", (this.type === (I$[3]||$incl$(3)).EXPORT ) ? 1 : 0]);
fd.setDirectory$S(C$.directory);
fd.setVisible$Z(true);
var file = fd.getFile();
var dir = fd.getDirectory();
if (dir != null ) C$.directory=dir;
if (file == null ) return;
System.err.println$S(dir + (I$[4]||$incl$(4)).separator + file );
if (this.type === (I$[3]||$incl$(3)).EXPORT ) {
try {
C$.writeFile$S(dir + file);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
} else {
try {
var dump = C$.readFile$S(dir + file);
C$.circuitDump=dump;
this.cframe.readSetup$S(C$.circuitDump);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'readFile$S', function (path) {
var stream = null;
try {
stream=Clazz.new_((I$[5]||$incl$(5)).c$$java_io_File,[Clazz.new_((I$[4]||$incl$(4)).c$$S,[path])]);
var fc = stream.getChannel();
var bb = fc.map$java_nio_channels_FileChannel_MapMode$J$J((I$[6]||$incl$(6)).READ_ONLY, 0, fc.size());
return (I$[7]||$incl$(7)).forName$S("UTF-8").decode$java_nio_ByteBuffer(bb).toString();
} finally {
stream.close();
}
}, 1);

Clazz.newMeth(C$, 'writeFile$S', function (path) {
var stream = null;
try {
stream=Clazz.new_((I$[8]||$incl$(8)).c$$java_io_File,[Clazz.new_((I$[4]||$incl$(4)).c$$S,[path])]);
var fc = stream.getChannel();
var bb = (I$[7]||$incl$(7)).forName$S("UTF-8").encode$S(C$.circuitDump);
fc.write$java_nio_ByteBuffer(bb);
} finally {
stream.close();
}
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:39 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
