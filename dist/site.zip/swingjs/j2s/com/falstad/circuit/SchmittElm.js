(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[[0,'com.falstad.circuit.CircuitElm','java.awt.Point']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SchmittElm", null, 'com.falstad.circuit.InvertingSchmittElm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['$gatePoly','java.awt.Polygon','+$symbolPoly']]]

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
;C$.superclazz.c$$I$I.apply(this,[xx, yy]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$java_util_StringTokenizer', function (xa, ya, xb, yb, f, st) {
;C$.superclazz.c$$I$I$I$I$I$java_util_StringTokenizer.apply(this,[xa, ya, xb, yb, f, st]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getDumpType$', function () {
return 182;
});

Clazz.newMeth(C$, 'doStep$', function () {
var v0=this.volts[1];
var out;
if (this.state) {
if (this.volts[0] > this.upperTrigger ) {
this.state=false;
out=5;
} else {
out=0;
}} else {
if (this.volts[0] < this.lowerTrigger ) {
this.state=true;
out=0;
} else {
out=5;
}}var maxStep=this.slewRate * $I$(1).sim.timeStep * 1.0E9 ;
out=Math.max(Math.min(v0 + maxStep, out), v0 - maxStep);
$I$(1).sim.updateVoltageSource$I$I$I$D(0, this.nodes[1], this.voltSource, out);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics', function (g) {
this.drawPosts$java_awt_Graphics(g);
this.draw2Leads$java_awt_Graphics(g);
g.setColor$java_awt_Color(this.needsHighlight$() ? $I$(1).selectColor : $I$(1).lightGrayColor);
$I$(1).drawThickPolygon$java_awt_Graphics$java_awt_Polygon(g, this.$gatePoly);
$I$(1).drawThickPolygon$java_awt_Graphics$java_awt_Polygon(g, this.$symbolPoly);
this.curcount=this.updateDotCount$D$D(this.current, this.curcount);
this.drawDots$java_awt_Graphics$java_awt_Point$java_awt_Point$D(g, this.lead2, this.point2, this.curcount);
});

Clazz.newMeth(C$, 'setPoints$', function () {
C$.superclazz.prototype.setPoints$.apply(this, []);
var hs=16;
var ww=16;
if (ww > this.dn / 2 ) ww=((this.dn / 2)|0);
this.lead1=this.interpPoint$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 0.5 - ww / this.dn);
this.lead2=this.interpPoint$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 0.5 + (ww - 3) / this.dn);
var triPoints=this.newPointArray$I(3);
var symPoints=this.newPointArray$I(6);
var dummy=Clazz.new_($I$(2,1).c$$I$I,[0, 0]);
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, triPoints[0], triPoints[1], 0, hs);
triPoints[2]=this.interpPoint$java_awt_Point$java_awt_Point$D(this.point1, this.point2, 0.5 + (ww - 5) / this.dn);
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, symPoints[4], symPoints[5], 0.25, (hs/4|0));
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, symPoints[2], symPoints[1], 0.4, (hs/4|0));
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, dummy, symPoints[0], 0.1, (hs/4|0));
this.interpPoint2$java_awt_Point$java_awt_Point$java_awt_Point$java_awt_Point$D$D(this.lead1, this.lead2, symPoints[3], dummy, 0.52, (hs/4|0));
this.$gatePoly=this.createPolygon$java_awt_PointA(triPoints);
this.$symbolPoly=this.createPolygon$java_awt_PointA(symPoints);
this.setBbox$java_awt_Point$java_awt_Point$D(this.point1, this.point2, hs);
});

Clazz.newMeth(C$, 'getInfo$SA', function (arr) {
arr[0]="Schmitt";
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:06:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
