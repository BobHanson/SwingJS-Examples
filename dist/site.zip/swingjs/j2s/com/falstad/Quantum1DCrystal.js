(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.Quantum1DCrystalFrame',['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairSetup'],['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairCoupledSetup'],['com.falstad.Quantum1DCrystalFrame','.HarmonicWellSetup'],['com.falstad.Quantum1DCrystalFrame','.CoulombWellArraySetup'],['com.falstad.Quantum1DCrystalFrame','.FreeParticleSetup'],['com.falstad.Quantum1DCrystalFrame','.SinusoidalLatticeSetup'],'java.awt.Color','java.util.Vector',['com.falstad.Quantum1DCrystalFrame','.FiniteWellSetup'],'com.falstad.Quantum1DCrystalLayout','com.falstad.Quantum1DCrystalCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','com.falstad.DecentScrollbar','java.util.Random','java.text.NumberFormat','java.awt.MenuItem','java.awt.CheckboxMenuItem','com.falstad.ButtonGroup','com.falstad.JRadioButtonMenuItem',['com.falstad.Quantum1DCrystalFrame','.View'],'java.awt.Cursor',['com.falstad.Quantum1DCrystalFrame','.FFT'],'gov.nist.jama.Matrix']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Quantum1DCrystal", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['qf','com.falstad.Quantum1DCrystalFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_Quantum1DCrystal,[null]);
C$.qf.init$();
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.qf == null ) {
this.started=true;
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_Quantum1DCrystal,[this]);
C$.qf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.qf == null ) s="Applet is finished.";
 else C$.qf.show$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:15 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
