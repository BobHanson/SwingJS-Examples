(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.EMWave2Frame',['com.falstad.EMWave2Frame','.DoubleSourceSetup'],['com.falstad.EMWave2Frame','.PlaneWaveSetup'],['com.falstad.EMWave2Frame','.IntersectingPlaneWavesSetup'],['com.falstad.EMWave2Frame','.SingleWireSetup'],['com.falstad.EMWave2Frame','.DoubleWireSetup'],['com.falstad.EMWave2Frame','.DipoleWireSetup'],['com.falstad.EMWave2Frame','.MagnetPairSetup'],['com.falstad.EMWave2Frame','.MagnetPairOppSetup'],['com.falstad.EMWave2Frame','.MagnetPairStackedSetup'],['com.falstad.EMWave2Frame','.MagnetPairStackedOppSetup'],['com.falstad.EMWave2Frame','.UniformFieldSetup'],['com.falstad.EMWave2Frame','.ApertureFieldSetup'],['com.falstad.EMWave2Frame','.SolenoidSetup'],['com.falstad.EMWave2Frame','.ToroidalSolenoidSetup'],['com.falstad.EMWave2Frame','.CylinderSetup'],['com.falstad.EMWave2Frame','.ThickWireSetup'],['com.falstad.EMWave2Frame','.HoleInWire1Setup'],['com.falstad.EMWave2Frame','.HoleInWire2Setup'],['com.falstad.EMWave2Frame','.FerromagnetSetup'],['com.falstad.EMWave2Frame','.DiamagnetSetup'],['com.falstad.EMWave2Frame','.MeissnerEffectSetup'],['com.falstad.EMWave2Frame','.HorseshoeSetup'],['com.falstad.EMWave2Frame','.Horseshoe2Setup'],['com.falstad.EMWave2Frame','.MagneticShielding1Setup'],['com.falstad.EMWave2Frame','.MagneticShielding2Setup'],['com.falstad.EMWave2Frame','.MagneticShielding3Setup'],['com.falstad.EMWave2Frame','.MagneticShielding4Setup'],['com.falstad.EMWave2Frame','.MagneticCircuit1Setup'],['com.falstad.EMWave2Frame','.MagneticCircuit2Setup'],['com.falstad.EMWave2Frame','.MonopoleAttemptSetup'],['com.falstad.EMWave2Frame','.QuadrupoleLensSetup'],['com.falstad.EMWave2Frame','.HalbachArraySetup'],['com.falstad.EMWave2Frame','.HalbachArray2Setup'],['com.falstad.EMWave2Frame','.HalbachArray3Setup'],['com.falstad.EMWave2Frame','.HalbachArray4Setup'],['com.falstad.EMWave2Frame','.DielectricSetup'],['com.falstad.EMWave2Frame','.ConductReflectSetup'],['com.falstad.EMWave2Frame','.Conduct2ReflectSetup'],['com.falstad.EMWave2Frame','.SkinEffect1Setup'],['com.falstad.EMWave2Frame','.SkinEffect2Setup'],['com.falstad.EMWave2Frame','.ResonantAbsSetup'],['com.falstad.EMWave2Frame','.Dispersion1Setup'],['com.falstad.EMWave2Frame','.Dispersion2Setup'],['com.falstad.EMWave2Frame','.Dispersion3Setup'],['com.falstad.EMWave2Frame','.Dispersion4Setup'],['com.falstad.EMWave2Frame','.DiffusionSetup'],['com.falstad.EMWave2Frame','.OscRingSetup'],['com.falstad.EMWave2Frame','.OscRingPairSetup'],['com.falstad.EMWave2Frame','.OscRingInductionSetup'],['com.falstad.EMWave2Frame','.WireInductionSetup'],['com.falstad.EMWave2Frame','.OscRingEddy1Setup'],['com.falstad.EMWave2Frame','.OscRingEddy2Setup'],['com.falstad.EMWave2Frame','.WireEddy1Setup'],['com.falstad.EMWave2Frame','.WireEddy2Setup'],['com.falstad.EMWave2Frame','.OscRingPermSetup'],['com.falstad.EMWave2Frame','.SolenoidOscSetup'],['com.falstad.EMWave2Frame','.TransformerSetup'],['com.falstad.EMWave2Frame','.ToroidalSolenoidOscSetup'],['com.falstad.EMWave2Frame','.CoaxCableSetup'],['com.falstad.EMWave2Frame','.CondInOscFieldSetup'],['com.falstad.EMWave2Frame','.MovingWireSetup'],['com.falstad.EMWave2Frame','.MovingWireTubeSetup'],['com.falstad.EMWave2Frame','.MovingMagnetSetup'],['com.falstad.EMWave2Frame','.RotatingMagnet1Setup'],['com.falstad.EMWave2Frame','.RotatingMagnet2Setup'],['com.falstad.EMWave2Frame','.Scattering1Setup'],['com.falstad.EMWave2Frame','.Scattering2Setup'],['com.falstad.EMWave2Frame','.BigModeSetup'],['com.falstad.EMWave2Frame','.OneByOneModesSetup'],['com.falstad.EMWave2Frame','.OneByNModesSetup'],['com.falstad.EMWave2Frame','.NByNModesSetup'],['com.falstad.EMWave2Frame','.OneByNModeCombosSetup'],['com.falstad.EMWave2Frame','.NByNModeCombosSetup'],['com.falstad.EMWave2Frame','.TriangleModesSetup'],['com.falstad.EMWave2Frame','.CircleModes1Setup'],['com.falstad.EMWave2Frame','.CircleModes2Setup'],['com.falstad.EMWave2Frame','.Waveguides1Setup'],['com.falstad.EMWave2Frame','.Waveguides2Setup'],['com.falstad.EMWave2Frame','.Waveguides3Setup'],['com.falstad.EMWave2Frame','.Waveguides4Setup'],['com.falstad.EMWave2Frame','.ResonantCavitiesSetup'],['com.falstad.EMWave2Frame','.SingleSlitSetup'],['com.falstad.EMWave2Frame','.DoubleSlitSetup'],['com.falstad.EMWave2Frame','.TripleSlitSetup'],['com.falstad.EMWave2Frame','.ObstacleSetup'],['com.falstad.EMWave2Frame','.HalfPlaneSetup'],['com.falstad.EMWave2Frame','.LloydsMirrorSetup'],'java.util.Vector',['com.falstad.EMWave2Frame','.SingleSourceSetup'],['com.falstad.EMWave2Frame','.OscSource'],'com.falstad.EMWave2Layout','com.falstad.EMWave2Canvas','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','java.awt.Scrollbar','java.util.Random','java.awt.Color',['com.falstad.EMWave2Frame','.OscElement'],'java.awt.image.MemoryImageSource']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EMWave2Layout", null, null, 'java.awt.LayoutManager');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1,1).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1,1).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets=target.insets$();
var targetw=target.size$().width - insets.left - insets.right ;
var cw=(targetw * 2/3|0);
var targeth=target.size$().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
var barwidth=targetw - cw;
cw+=insets.left;
var i;
var h=insets.top;
for (i=1; i < target.getComponentCount$(); i++) {
var m=target.getComponent$I(i);
if (m.isVisible$()) {
var d=m.getPreferredSize$();
if (Clazz.instanceOf(m, "java.awt.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "java.awt.Choice") && d.width > barwidth ) d.width=barwidth;
if (Clazz.instanceOf(m, "java.awt.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
