(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.Quantum1DCrystalFrame',['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairSetup'],['com.falstad.Quantum1DCrystalFrame','.FiniteWellPairCoupledSetup'],['com.falstad.Quantum1DCrystalFrame','.HarmonicWellSetup'],['com.falstad.Quantum1DCrystalFrame','.CoulombWellArraySetup'],['com.falstad.Quantum1DCrystalFrame','.FreeParticleSetup'],['com.falstad.Quantum1DCrystalFrame','.SinusoidalLatticeSetup'],'java.awt.Color','java.util.Vector',['com.falstad.Quantum1DCrystalFrame','.FiniteWellSetup'],'com.falstad.Quantum1DCrystalLayout','com.falstad.Quantum1DCrystalCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','com.falstad.DecentScrollbar','java.util.Random','java.text.NumberFormat','java.awt.MenuItem','java.awt.CheckboxMenuItem','com.falstad.ButtonGroup','com.falstad.JRadioButtonMenuItem',['com.falstad.Quantum1DCrystalFrame','.View'],'java.awt.Cursor',['com.falstad.Quantum1DCrystalFrame','.FFT'],'gov.nist.jama.Matrix']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Quantum1DCrystalCanvas", null, 'java.awt.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.Quantum1DCrystalFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_Quantum1DCrystalFrame', function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateQuantum1DCrystal$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.pg.updateQuantum1DCrystal$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:15 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
