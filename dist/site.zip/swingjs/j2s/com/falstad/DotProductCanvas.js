(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Color','java.awt.Dimension','com.falstad.DotProductLayout','com.falstad.DotProductCanvas','java.awt.Button','java.util.Random','java.awt.Font','java.text.NumberFormat']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DotProductCanvas", null, 'java.awt.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.DotProduct']]]

Clazz.newMeth(C$, 'c$$com_falstad_DotProduct', function (p) {
Clazz.super_(C$, this);
this.pg=p;
this.setBackground$java_awt_Color($I$(1).BLACK);
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(2,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateDotProduct$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.pg.updateDotProduct$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
