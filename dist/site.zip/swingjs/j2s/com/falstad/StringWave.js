(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},I$=[[0,'com.falstad.StringWaveFrame','java.awt.Dimension','java.awt.Color',['com.falstad.StringWaveFrame','.StringWaveLayout'],['com.falstad.StringWaveFrame','.StringWaveCanvas'],'java.awt.Button','java.awt.Checkbox','java.awt.Choice','java.awt.Label','java.awt.Scrollbar','java.util.Random','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat','com.falstad.StringWave','com.falstad.FFT']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StringWave", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['ogf','com.falstad.StringWaveFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.showFrame$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_StringWave,[null]);
C$.ogf.init$();
}, 1);

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_StringWave,[this]);
C$.ogf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow$();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:55 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
