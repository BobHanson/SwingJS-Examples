(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.DiffEqFrame',['com.falstad.DiffEqFrame','.Order1LhsFunc'],['com.falstad.DiffEqFrame','.Order2LhsFunc'],['com.falstad.DiffEqFrame','.FreeFallLhsFunc'],['com.falstad.DiffEqFrame','.BesselLhsFunc'],['com.falstad.DiffEqFrame','.BesselIntegerLhsFunc'],['com.falstad.DiffEqFrame','.BesselHalfIntegerLhsFunc'],['com.falstad.DiffEqFrame','.LegendreLhsFunc'],['com.falstad.DiffEqFrame','.LegendreIntegerLhsFunc'],['com.falstad.DiffEqFrame','.HermiteLhsFunc'],['com.falstad.DiffEqFrame','.JacobiLhsFunc'],['com.falstad.DiffEqFrame','.Order4LhsFunc'],['com.falstad.DiffEqFrame','.EquidimensionalOrder2LhsFunc'],['com.falstad.DiffEqFrame','.PendulumLhsFunc'],['com.falstad.DiffEqFrame','.DuffingLhsFunc'],['com.falstad.DiffEqFrame','.VanDerPolFunc'],['com.falstad.DiffEqFrame','.ImpulseRhsFunc'],['com.falstad.DiffEqFrame','.StepRhsFunc'],['com.falstad.DiffEqFrame','.SquareWaveRhsFunc'],['com.falstad.DiffEqFrame','.SineWaveRhsFunc'],['com.falstad.DiffEqFrame','.SawtoothRhsFunc'],['com.falstad.DiffEqFrame','.TriangleRhsFunc'],['com.falstad.DiffEqFrame','.LinearRhsFunc'],['com.falstad.DiffEqFrame','.ExponentialRhsFunc'],['com.falstad.DiffEqFrame','.CustomRhsFunc'],['com.falstad.DiffEqFrame','.CustomYRhsFunc'],['com.falstad.DiffEqFrame','.CustomYPRhsFunc'],'java.awt.Color','java.util.Vector',['com.falstad.DiffEqFrame','.OscillatorLhsFunc'],['com.falstad.DiffEqFrame','.ZeroRhsFunc'],'com.falstad.DiffEqLayout','com.falstad.DiffEqCanvas','a2s.Choice','a2s.Button',['com.falstad.DiffEqFrame','.ValueEditCanvas'],'java.text.NumberFormat','java.util.Random']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DiffEqLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.insets();
var targetw = target.size().width - insets.left - insets.right ;
var targeth = target.size().height - (insets.top + insets.bottom);
var ch = (targeth * 2/3|0);
var m = target.getComponent$I(0);
m.move$I$I(insets.left, insets.top);
m.resize$I$I(targetw, ch);
var x = insets.left;
var i;
var mh = 0;
ch+=insets.top;
for (i=1; i != 4; i++) {
m=target.getComponent$I(i);
var d = m.getPreferredSize();
m.move$I$I(x, ch);
m.resize$I$I(d.width, d.height);
x+=d.width;
if (d.height > mh) mh=d.height;
}
ch+=mh;
var h = ch;
var cw = (target.size().width/3|0);
x=insets.left;
var cn = 0;
for (; i < target.getComponentCount(); i++) {
m=target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
d.width=cw;
m.move$I$I(x, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}cn++;
if (cn == 5) {
cn=0;
x+=cw;
h=ch;
}}
});
})();
//Created 2018-07-24 06:44:30 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
