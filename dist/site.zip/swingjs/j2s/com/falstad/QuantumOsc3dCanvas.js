(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumOsc3dFrame','com.falstad.Complex','java.awt.Color','com.falstad.QuantumOsc3dLayout','com.falstad.QuantumOsc3dCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Checkbox','java.awt.Button','java.awt.Label','java.awt.Scrollbar',['com.falstad.QuantumOsc3dFrame','.PhaseColor'],'java.util.Random',['com.falstad.QuantumOsc3dFrame','.BasisState'],['com.falstad.QuantumOsc3dFrame','.AlternateBasis'],['com.falstad.QuantumOsc3dFrame','.DerivedState'],'java.awt.MenuItem','java.awt.CheckboxMenuItem',['com.falstad.QuantumOsc3dFrame','.TextBox'],['com.falstad.QuantumOsc3dFrame','.Phasor'],['com.falstad.QuantumOsc3dFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle',['com.falstad.QuantumOsc3dFrame','.Orbital'],['com.falstad.QuantumOsc3dFrame','.SOrbital'],['com.falstad.QuantumOsc3dFrame','.MZeroOrbital'],['com.falstad.QuantumOsc3dFrame','.PairedOrbital']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumOsc3dCanvas", null, 'java.awt.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.QuantumOsc3dFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_QuantumOsc3dFrame', function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateQuantumOsc3d$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.pg.updateQuantumOsc3d$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:55 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
