(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.util.ArrayList']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ButtonGroup");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.items=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['items','java.util.ArrayList']]]

Clazz.newMeth(C$, 'add$com_falstad_JRadioButtonMenuItem', function (item) {
this.items.add$O(item);
item.group=this;
});

Clazz.newMeth(C$, 'set$com_falstad_JRadioButtonMenuItem', function (item) {
for (var i=0; i < this.items.size$(); i++) {
if (this.items.get$I(i) !== item ) {
this.items.get$I(i).select$Z(false);
}}
});

Clazz.newMeth(C$, 'getSelection$', function () {
for (var i=0; i < this.items.size$(); i++) {
if (this.items.get$I(i).selected$()) {
return this.items.get$I(i);
}}
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:14 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
