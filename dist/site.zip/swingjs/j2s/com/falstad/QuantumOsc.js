(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumOscFrame','com.falstad.QuantumOscLayout','com.falstad.QuantumOscCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar',['com.falstad.QuantumOscFrame','.PhaseColor'],'java.awt.Color','java.util.Random','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumOscFrame','.View'],['com.falstad.QuantumOscFrame','.Phasor'],'java.awt.image.MemoryImageSource','com.falstad.Complex',['com.falstad.QuantumOscFrame','.BasisState'],['com.falstad.QuantumOscFrame','.DerivedState']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "QuantumOsc", null, 'a2s.Applet');
C$.mf=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.mf=Clazz.new_($I$(2).c$$com_falstad_QuantumOsc,[null]);
C$.mf.init$();
}, 1);

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$, ['init$','init'], function () {
C$.mf=Clazz.new_($I$(2).c$$com_falstad_QuantumOsc,[this]);
C$.mf.init$();
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:21 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
