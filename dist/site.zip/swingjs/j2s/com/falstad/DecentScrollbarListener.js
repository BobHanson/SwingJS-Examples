(function(){var P$=Clazz.newPackage("com.falstad"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DecentScrollbarListener");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
