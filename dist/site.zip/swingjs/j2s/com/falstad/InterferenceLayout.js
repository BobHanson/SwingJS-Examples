(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},I$=[[0,'java.awt.Dimension','com.falstad.InterferenceFrame','java.text.NumberFormat','com.falstad.InterferenceLayout','com.falstad.InterferenceCanvas','java.awt.Checkbox','java.awt.Label','java.awt.Scrollbar','java.awt.Color','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "InterferenceLayout", null, null, 'java.awt.LayoutManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1).c$$I$I,[500, 500]);
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_($I$(1).c$$I$I,[100, 100]);
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var barwidth=0;
var i;
for (i=1; i < target.getComponentCount$(); i++) {
var m=target.getComponent$I(i);
if (m.isVisible$()) {
var d=m.getPreferredSize$();
if (d.width > barwidth) barwidth=d.width;
}}
var insets=target.insets$();
var targetw=target.size$().width - insets.left - insets.right ;
var cw=targetw - barwidth;
var targeth=target.size$().height - (insets.top + insets.bottom);
target.getComponent$I(0).move$I$I(insets.left, insets.top);
target.getComponent$I(0).resize$I$I(cw, targeth);
cw+=insets.left;
var h=insets.top;
for (i=1; i < target.getComponentCount$(); i++) {
var m=target.getComponent$I(i);
if (m.isVisible$()) {
var d=m.getPreferredSize$();
if (Clazz.instanceOf(m, "java.awt.Scrollbar")) d.width=barwidth;
if (Clazz.instanceOf(m, "java.awt.Label")) {
h+=(d.height/5|0);
d.width=barwidth;
}m.move$I$I(cw, h);
m.resize$I$I(d.width, d.height);
h+=d.height;
}}
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:21 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
