(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumStatesFrame',['com.falstad.QuantumStatesFrame','.FiniteWellSetup'],['com.falstad.QuantumStatesFrame','.HarmonicOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumStatesFrame','.AsymmetricWellSetup'],['com.falstad.QuantumStatesFrame','.InfiniteWellFieldSetup'],['com.falstad.QuantumStatesFrame','.WellPairCoupledFieldSetup'],['com.falstad.QuantumStatesFrame','.CoulombSetup'],['com.falstad.QuantumStatesFrame','.QuarticOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArraySetup'],['com.falstad.QuantumStatesFrame','.HarmonicWellArraySetup'],['com.falstad.QuantumStatesFrame','.CoulombWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayFieldSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayImpureSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayDislocSetup'],['com.falstad.QuantumStatesFrame','.RandomWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWell2ArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellCoupledArraySetup'],['com.falstad.QuantumStatesFrame','.DeltaArraySetup'],'java.util.Vector',['com.falstad.QuantumStatesFrame','.InfiniteWellSetup'],'com.falstad.QuantumStatesLayout','com.falstad.QuantumStatesCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','java.text.NumberFormat','java.awt.MenuItem','java.awt.CheckboxMenuItem','com.falstad.ButtonGroup','com.falstad.JRadioButtonMenuItem',['com.falstad.QuantumStatesFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumStatesFrame','.FFT']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumStates", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['qf','com.falstad.QuantumStatesFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.qf == null ) {
this.started=true;
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumStates,[this]);
C$.qf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.qf=Clazz.new_($I$(2,1).c$$com_falstad_QuantumStates,[null]);
C$.qf.init$();
}, 1);

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.qf == null ) s="Applet is finished.";
 else C$.qf.show$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:01:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
