(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumStatesFrame',['com.falstad.QuantumStatesFrame','.FiniteWellSetup'],['com.falstad.QuantumStatesFrame','.HarmonicOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumStatesFrame','.AsymmetricWellSetup'],['com.falstad.QuantumStatesFrame','.InfiniteWellFieldSetup'],['com.falstad.QuantumStatesFrame','.WellPairCoupledFieldSetup'],['com.falstad.QuantumStatesFrame','.CoulombSetup'],['com.falstad.QuantumStatesFrame','.QuarticOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArraySetup'],['com.falstad.QuantumStatesFrame','.HarmonicWellArraySetup'],['com.falstad.QuantumStatesFrame','.CoulombWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayFieldSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayImpureSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayDislocSetup'],['com.falstad.QuantumStatesFrame','.RandomWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWell2ArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellCoupledArraySetup'],['com.falstad.QuantumStatesFrame','.DeltaArraySetup'],'java.util.Vector',['com.falstad.QuantumStatesFrame','.InfiniteWellSetup'],'com.falstad.QuantumStatesLayout','com.falstad.QuantumStatesCanvas','a2s.MenuBar','a2s.Menu','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','java.text.NumberFormat','a2s.MenuItem','a2s.CheckboxMenuItem','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem',['com.falstad.QuantumStatesFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumStatesFrame','.FFT']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "QuantumStates", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.qf=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.qf == null ) {
this.started=true;
C$.qf=Clazz.new_($I$(2).c$$com_falstad_QuantumStates,[this]);
C$.qf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.qf=Clazz.new_($I$(2).c$$com_falstad_QuantumStates,[null]);
C$.qf.init$();
}, 1);

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.qf == null ) s="Applet is finished.";
 else C$.qf.show$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.qf != null ) C$.qf.dispose$();
C$.qf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:22 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
