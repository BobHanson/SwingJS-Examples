(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.DispersionFrame','com.falstad.DispersionLayout','com.falstad.DispersionCanvas','a2s.Checkbox','a2s.Label','com.falstad.DecentScrollbar','a2s.Button','java.util.Random','java.awt.Color','java.text.NumberFormat',['com.falstad.DispersionFrame','.View']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DispersionCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_DispersionFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateDispersion$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
this.pg.updateDispersion$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:31 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
