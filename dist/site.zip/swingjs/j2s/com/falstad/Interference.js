(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},I$=[[0,'java.awt.Dimension','com.falstad.InterferenceFrame','java.text.NumberFormat','com.falstad.InterferenceLayout','com.falstad.InterferenceCanvas','java.awt.Checkbox','java.awt.Label','java.awt.Scrollbar','java.awt.Color','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Interference", null, 'java.applet.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['ff','com.falstad.InterferenceFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ff != null ) C$.ff.dispose$();
C$.ff=null;
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ff=Clazz.new_($I$(2,1).c$$com_falstad_Interference,[null]);
C$.ff.init$();
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
C$.ff=Clazz.new_($I$(2,1).c$$com_falstad_Interference,[this]);
C$.ff.init$();
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ff != null ) C$.ff.dispose$();
C$.ff=null;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ff == null ) s="Applet is finished.";
 else if (C$.ff.useFrame) C$.ff.triggerShow$();
if (C$.ff == null  || C$.ff.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:55 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
