(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.EMStaticFrame',['com.falstad.EMStaticFrame','.DoubleChargeSetup'],['com.falstad.EMStaticFrame','.DipoleChargeSetup'],['com.falstad.EMStaticFrame','.ChargePlaneSetup'],['com.falstad.EMStaticFrame','.DipoleUniformSetup'],['com.falstad.EMStaticFrame','.QuadChargeSetup'],['com.falstad.EMStaticFrame','.ConductingPlanesSetup'],['com.falstad.EMStaticFrame','.ChargedPlanesSetup'],['com.falstad.EMStaticFrame','.ConductingCylinderSetup'],['com.falstad.EMStaticFrame','.GroundedCylinderSetup'],['com.falstad.EMStaticFrame','.GroundedCylinderUniformSetup'],['com.falstad.EMStaticFrame','.ChargedCylinderSetup'],['com.falstad.EMStaticFrame','.ChargedHollowCylinder1Setup'],['com.falstad.EMStaticFrame','.ChargedHollowCylinder2Setup'],['com.falstad.EMStaticFrame','.FloatingCylinderSetup'],['com.falstad.EMStaticFrame','.FloatingCylinder2Setup'],['com.falstad.EMStaticFrame','.ConductingBoxSetup'],['com.falstad.EMStaticFrame','.HollowFloatingCylinderSetup'],['com.falstad.EMStaticFrame','.HollowFloatingCylinder2Setup'],['com.falstad.EMStaticFrame','.SharpPointSetup'],['com.falstad.EMStaticFrame','.CornerSetup'],['com.falstad.EMStaticFrame','.Angle45Setup'],['com.falstad.EMStaticFrame','.Angle135Setup'],['com.falstad.EMStaticFrame','.DielectricCylinderSetup'],['com.falstad.EMStaticFrame','.DielectricCylinderFieldSetup'],['com.falstad.EMStaticFrame','.Dielectric1Setup'],['com.falstad.EMStaticFrame','.Dielectric2Setup'],['com.falstad.EMStaticFrame','.DielectricDipoleSetup'],['com.falstad.EMStaticFrame','.DielecCapSetup'],['com.falstad.EMStaticFrame','.ConductingPlanesGapSetup'],['com.falstad.EMStaticFrame','.SlottedConductingPlaneSetup'],['com.falstad.EMStaticFrame','.Shielding1Setup'],['com.falstad.EMStaticFrame','.Shielding2Setup'],['com.falstad.EMStaticFrame','.BoxOneSideSetup'],['com.falstad.EMStaticFrame','.QuadrupoleLensSetup'],['com.falstad.EMStaticFrame','.ConductingWireSetup'],['com.falstad.EMStaticFrame','.ResistorSetup'],['com.falstad.EMStaticFrame','.ResistorsParallelSetup'],['com.falstad.EMStaticFrame','.Current2D1Setup'],['com.falstad.EMStaticFrame','.Current2D2Setup'],'java.util.Vector',['com.falstad.EMStaticFrame','.SingleChargeSetup'],['com.falstad.EMStaticFrame','.Charge'],'com.falstad.EMStaticLayout','com.falstad.EMStaticCanvas','a2s.Choice','a2s.Button','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color',['com.falstad.EMStaticFrame','.GridElement'],['com.falstad.EMStaticFrame','.SolverGrid'],'java.text.NumberFormat',['com.falstad.EMStaticFrame','.SolverElement'],'java.awt.Point']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMStaticCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_EMStaticFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateEMStatic$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateEMStatic$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:31 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
