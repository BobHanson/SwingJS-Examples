(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.AtomViewerFrame','com.falstad.Complex','java.awt.Color','com.falstad.AtomViewerLayout','com.falstad.AtomViewerCanvas','a2s.MenuBar','a2s.Menu','javax.swing.JRadioButtonMenuItem','javax.swing.ButtonGroup','a2s.Choice','a2s.Checkbox','a2s.Button','a2s.Label','a2s.Scrollbar',['com.falstad.AtomViewerFrame','.PhaseColor'],'java.util.Random',['com.falstad.AtomViewerFrame','.BasisState'],['com.falstad.AtomViewerFrame','.AlternateBasis'],['com.falstad.AtomViewerFrame','.DerivedState'],'a2s.MenuItem','a2s.CheckboxMenuItem',['com.falstad.AtomViewerFrame','.TextBox'],['com.falstad.AtomViewerFrame','.Phasor'],['com.falstad.AtomViewerFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle',['com.falstad.AtomViewerFrame','.Orbital'],['com.falstad.AtomViewerFrame','.SOrbital'],['com.falstad.AtomViewerFrame','.MZeroOrbital'],['com.falstad.AtomViewerFrame','.PairedOrbital']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AtomViewerCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_AtomViewerFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateAtomViewer$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateAtomViewer$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:29 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
