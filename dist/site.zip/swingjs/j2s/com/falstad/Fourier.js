(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},I$=[[0,'java.awt.Dimension','com.falstad.FourierFrame','java.awt.Button','java.awt.Checkbox','java.util.Hashtable','java.util.StringTokenizer','java.util.Random','com.falstad.FFT','com.falstad.FourierLayout','com.falstad.FourierCanvas','java.awt.Label','java.awt.Scrollbar','java.awt.Color','java.text.NumberFormat',['com.falstad.FourierFrame','.View'],'java.awt.Font','com.falstad.Fourier','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Fourier", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');
C$.ogf=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.showFrame$();
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.showFrame$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(2).c$$com_falstad_Fourier,[null]);
C$.ogf.initFrame$();
}, 1);

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_($I$(2).c$$com_falstad_Fourier,[this]);
C$.ogf.initFrame$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow$();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:20 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
