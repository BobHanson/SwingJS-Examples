(function(){var P$=Clazz.newPackage("com.falstad"),p$1={},p$2={},I$=[[0,'com.falstad.VowelFrame','java.awt.Color','com.falstad.Complex','com.falstad.FFT',['com.falstad.VowelFrame','.DirectFilter'],'java.awt.Dimension',['com.falstad.VowelFrame','.ImportDialogLayout'],'java.awt.TextArea','java.awt.Button','com.falstad.Vowel','javax.sound.sampled.AudioFormat',['javax.sound.sampled.DataLine','.Info'],'javax.sound.sampled.SourceDataLine','javax.sound.sampled.AudioSystem',['com.falstad.VowelFrame','.PhaseColor'],['com.falstad.VowelFrame','.VowelLayout'],['com.falstad.VowelFrame','.VowelCanvas'],'java.awt.MenuBar','java.awt.Menu','java.awt.Checkbox','java.awt.Choice','java.awt.Label','java.awt.Scrollbar','java.util.Random','java.text.NumberFormat','java.awt.MenuItem','java.awt.CheckboxMenuItem',['com.falstad.VowelFrame','.View'],['com.falstad.VowelFrame','.AVowelFilter'],['com.falstad.VowelFrame','.OVowelFilter'],['com.falstad.VowelFrame','.UVowelFilter'],['com.falstad.VowelFrame','.IVowelFilter'],['com.falstad.VowelFrame','.EVowelFilter'],['com.falstad.VowelFrame','.IBarVowelFilter'],['com.falstad.VowelFrame','.AVowelFilterSimple'],['com.falstad.VowelFrame','.IVowelFilterSimple'],['com.falstad.VowelFrame','.AEVowelFilterSimple'],['com.falstad.VowelFrame','.IhVowelFilterSimple'],['com.falstad.VowelFrame','.OoVowelFilterSimple'],['com.falstad.VowelFrame','.YVowelFilterSimple'],['com.falstad.VowelFrame','.OpenTubeFilter'],['com.falstad.VowelFrame','.CustomFilter'],['com.falstad.VowelFrame','.NoFilter'],['com.falstad.VowelFrame','.NoiseWaveform'],['com.falstad.VowelFrame','.VocalWaveform'],['com.falstad.VowelFrame','.SawtoothWaveform'],['com.falstad.VowelFrame','.PeriodicNoiseWaveform'],['com.falstad.VowelFrame','.TriangleWaveform'],['com.falstad.VowelFrame','.SquareWaveform'],['com.falstad.VowelFrame','.SineWaveform'],['com.falstad.VowelFrame','.SweepWaveform'],['com.falstad.VowelFrame','.ImpulseWaveform'],['com.falstad.VowelFrame','.ImportDialog'],'java.util.StringTokenizer',['com.falstad.VowelFrame','.PlayThread']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Vowel", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
this.security=false;
},1);

C$.$fields$=[['Z',['started','security']]
,['O',['ogf','com.falstad.VowelFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.showFrame$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_Vowel,[null]);
C$.ogf.init$();
}, 1);

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.ogf == null ) {
this.started=true;
try {
C$.ogf=Clazz.new_($I$(1,1).c$$com_falstad_Vowel,[this]);
C$.ogf.init$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
C$.ogf=null;
this.security=true;
this.repaint$();
} else {
throw e;
}
}
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (this.security) s="Security exception, use nosound version";
 else if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow$();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
