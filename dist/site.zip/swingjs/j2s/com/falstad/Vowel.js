(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['com.falstad.VowelFrame','java.awt.Color','com.falstad.Complex','com.falstad.FFT',['com.falstad.VowelFrame','.DirectFilter'],'java.awt.Dimension',['com.falstad.VowelFrame','.ImportDialogLayout'],'a2s.TextArea','a2s.Button','com.falstad.Vowel','javax.sound.sampled.AudioFormat',['javax.sound.sampled.DataLine','.Info'],'javax.sound.sampled.SourceDataLine','javax.sound.sampled.AudioSystem',['com.falstad.VowelFrame','.PhaseColor'],['com.falstad.VowelFrame','.VowelLayout'],['com.falstad.VowelFrame','.VowelCanvas'],'a2s.MenuBar','a2s.Menu','a2s.Checkbox','a2s.Choice','a2s.Label','a2s.Scrollbar','java.util.Random','java.text.NumberFormat','a2s.MenuItem','a2s.CheckboxMenuItem',['com.falstad.VowelFrame','.View'],['com.falstad.VowelFrame','.AVowelFilter'],['com.falstad.VowelFrame','.OVowelFilter'],['com.falstad.VowelFrame','.UVowelFilter'],['com.falstad.VowelFrame','.IVowelFilter'],['com.falstad.VowelFrame','.EVowelFilter'],['com.falstad.VowelFrame','.IBarVowelFilter'],['com.falstad.VowelFrame','.AVowelFilterSimple'],['com.falstad.VowelFrame','.IVowelFilterSimple'],['com.falstad.VowelFrame','.AEVowelFilterSimple'],['com.falstad.VowelFrame','.IhVowelFilterSimple'],['com.falstad.VowelFrame','.OoVowelFilterSimple'],['com.falstad.VowelFrame','.YVowelFilterSimple'],['com.falstad.VowelFrame','.OpenTubeFilter'],['com.falstad.VowelFrame','.CustomFilter'],['com.falstad.VowelFrame','.NoFilter'],['com.falstad.VowelFrame','.NoiseWaveform'],['com.falstad.VowelFrame','.VocalWaveform'],['com.falstad.VowelFrame','.SawtoothWaveform'],['com.falstad.VowelFrame','.PeriodicNoiseWaveform'],['com.falstad.VowelFrame','.TriangleWaveform'],['com.falstad.VowelFrame','.SquareWaveform'],['com.falstad.VowelFrame','.SineWaveform'],['com.falstad.VowelFrame','.SweepWaveform'],['com.falstad.VowelFrame','.ImpulseWaveform'],['com.falstad.VowelFrame','.ImportDialog'],'java.util.StringTokenizer',['com.falstad.VowelFrame','.PlayThread']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Vowel", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
this.security = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
this.security = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.showFrame();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf=Clazz.new_((I$[1]||$incl$(1)).c$$com_falstad_Vowel,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started=true;
try {
C$.ogf=Clazz.new_((I$[1]||$incl$(1)).c$$com_falstad_Vowel,[this]);
C$.ogf.init();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
C$.ogf=null;
this.security=true;
this.repaint();
} else {
throw e;
}
}
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (this.security) s="Security exception, use nosound version";
 else if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:38 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
