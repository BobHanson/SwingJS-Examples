(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.CircOscFrame','com.falstad.CircOscLayout','com.falstad.CircOscCanvas','a2s.Button','a2s.Checkbox','a2s.Choice','a2s.Label','a2s.Scrollbar','java.util.Random','java.awt.Color',['com.falstad.CircOscFrame','.View'],'java.awt.image.MemoryImageSource','com.falstad.FFT','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircOsc", null, 'a2s.Applet', 'java.awt.event.ComponentListener');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
this.security = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
this.security = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$, 'init', function () {
this.showFrame();
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_CircOsc,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started=true;
try {
C$.ogf=Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_CircOsc,[this]);
C$.ogf.init();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
C$.ogf=null;
this.security=true;
this.repaint();
} else {
throw e;
}
}
this.repaint();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (this.security) s="Security exception, use nosound version";
 else if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf=null;
this.repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:30 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
