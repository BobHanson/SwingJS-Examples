(function(){var P$=Clazz.newPackage("com.falstad"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JRadioButtonMenuItem", null, 'java.awt.CheckboxMenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['group','com.falstad.ButtonGroup']]]

Clazz.newMeth(C$, 'c$$S', function (s) {
;C$.superclazz.c$$S.apply(this,[s]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'selected$', function () {
return this.getState$();
});

Clazz.newMeth(C$, 'select$Z', function (b) {
if (b && this.group != null  ) this.group.set$com_falstad_JRadioButtonMenuItem(this);
this.setState$Z(b);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:15 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
