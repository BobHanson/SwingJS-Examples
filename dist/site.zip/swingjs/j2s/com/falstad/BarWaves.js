(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'com.falstad.BarWavesFrame',['com.falstad.BarWavesFrame','.HingedBarSetup'],['com.falstad.BarWavesFrame','.ClampedBarSetup'],['com.falstad.BarWavesFrame','.ClampedFreeBarSetup'],['com.falstad.BarWavesFrame','.HingedClampedBarSetup'],['com.falstad.BarWavesFrame','.StringSetup'],['com.falstad.BarWavesFrame','.String1FreeSetup'],['com.falstad.BarWavesFrame','.String2FreeSetup'],['com.falstad.BarWavesFrame','.StiffStringSetup'],['com.falstad.BarWavesFrame','.StiffStringClampedSetup'],'java.awt.Dimension','java.awt.Color','java.util.Vector',['com.falstad.BarWavesFrame','.FreeBarSetup'],['com.falstad.BarWavesFrame','.BarWavesLayout'],['com.falstad.BarWavesFrame','.BarWavesCanvas'],'java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','java.awt.Scrollbar','java.util.Random','javajs.util.JSAudioThread']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BarWaves", null, 'java.applet.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['mf','com.falstad.BarWavesFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$, ['start$','start'], function () {
C$.mf=Clazz.new_($I$(1,1).c$$com_falstad_BarWaves,[this]);
C$.mf.init$();
C$.mf.handleResize$();
System.out.println$S("init");
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.mf=Clazz.new_($I$(1,1).c$$com_falstad_BarWaves,[null]);
C$.mf.init$();
}, 1);

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.mf != null ) C$.mf.dispose$();
C$.mf=null;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
System.out.println$O(C$.mf.cv.getSize$());
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.mf == null ) s="Applet is finished.";
 else if (C$.mf.useFrame) C$.mf.triggerShow$();
if (C$.mf == null  || C$.mf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-20 09:16:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
