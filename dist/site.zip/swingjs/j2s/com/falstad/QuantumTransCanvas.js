(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumTransFrame',['com.falstad.QuantumTransFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumTransFrame','.HarmonicOscillatorSetup'],'java.util.Vector',['com.falstad.QuantumTransFrame','.InfiniteWellSetup'],'com.falstad.QuantumTransLayout','com.falstad.QuantumTransCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','java.awt.MenuItem','java.awt.CheckboxMenuItem','com.falstad.ButtonGroup','com.falstad.JRadioButtonMenuItem',['com.falstad.QuantumTransFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumTransFrame','.FFT']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumTransCanvas", null, 'java.awt.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.QuantumTransFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_QuantumTransFrame', function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateQuantumTrans$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.pg.updateQuantumTrans$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:15 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
