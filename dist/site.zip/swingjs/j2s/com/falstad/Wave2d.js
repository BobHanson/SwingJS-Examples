(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.Wave2dFrame',['com.falstad.Wave2dFrame','.DoubleSlitSetup'],['com.falstad.Wave2dFrame','.GratingSetup'],['com.falstad.Wave2dFrame','.ObstacleSetup'],['com.falstad.Wave2dFrame','.ZonePlateEvenSetup'],['com.falstad.Wave2dFrame','.ZonePlateOddSetup'],['com.falstad.Wave2dFrame','.ZonePlatePhaseSetup'],['com.falstad.Wave2dFrame','.ZonePlateBlazedSetup'],['com.falstad.Wave2dFrame','.Hologram1Setup'],['com.falstad.Wave2dFrame','.Hologram2Setup'],'java.util.Vector',['com.falstad.Wave2dFrame','.SingleSlitSetup'],'com.falstad.Wave2dLayout','com.falstad.Wave2dCanvas','java.awt.Choice','java.awt.Checkbox','java.awt.Button','java.awt.Label','java.awt.Scrollbar','java.util.Random','java.awt.Color','java.awt.image.MemoryImageSource','com.falstad.FFT','java.text.NumberFormat']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Wave2d", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');
C$.ogf=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.showFrame$();
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(2).c$$com_falstad_Wave2d,[null]);
C$.ogf.initFrame$();
}, 1);

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_($I$(2).c$$com_falstad_Wave2d,[this]);
C$.ogf.initFrame$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow$();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:23 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
