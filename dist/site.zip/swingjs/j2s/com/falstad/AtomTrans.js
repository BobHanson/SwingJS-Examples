(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.AtomTransFrame','java.awt.Color','com.falstad.AtomTransLayout','com.falstad.AtomTransCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Checkbox','java.awt.Label','java.awt.Scrollbar',['com.falstad.AtomTransFrame','.PhaseColor'],'java.util.Random',['com.falstad.AtomTransFrame','.BasisState'],'java.awt.MenuItem','java.awt.CheckboxMenuItem',['com.falstad.AtomTransFrame','.Phasor'],['com.falstad.AtomTransFrame','.View'],'java.awt.image.MemoryImageSource','java.awt.Rectangle','com.falstad.Complex',['com.falstad.AtomTransFrame','.Orbital'],['com.falstad.AtomTransFrame','.SOrbital'],['com.falstad.AtomTransFrame','.MZeroOrbital'],['com.falstad.AtomTransFrame','.PairedOrbital']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomTrans", null, 'java.applet.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.started=false;
},1);

C$.$fields$=[['Z',['started']]
,['O',['ogf','com.falstad.AtomTransFrame']]]

Clazz.newMeth(C$, 'destroyFrame$', function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.addComponentListener$java_awt_event_ComponentListener(this);
});

Clazz.newMeth(C$, 'main$SA', function (args) {
C$.ogf=Clazz.new_($I$(2,1).c$$com_falstad_AtomTrans,[null]);
C$.ogf.init$();
}, 1);

Clazz.newMeth(C$, 'showFrame$', function () {
if (C$.ogf == null ) {
this.started=true;
C$.ogf=Clazz.new_($I$(2,1).c$$com_falstad_AtomTrans,[this]);
C$.ogf.init$();
this.repaint$();
}});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s="Applet is open in a separate window.";
if (!this.started) s="Applet is starting.";
 else if (C$.ogf == null ) s="Applet is finished.";
 else C$.ogf.show$();
g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$, ['componentHidden$java_awt_event_ComponentEvent','componentHidden'], function (e) {
});

Clazz.newMeth(C$, ['componentMoved$java_awt_event_ComponentEvent','componentMoved'], function (e) {
});

Clazz.newMeth(C$, ['componentShown$java_awt_event_ComponentEvent','componentShown'], function (e) {
this.showFrame$();
});

Clazz.newMeth(C$, ['componentResized$java_awt_event_ComponentEvent','componentResized'], function (e) {
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (C$.ogf != null ) C$.ogf.dispose$();
C$.ogf=null;
this.repaint$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-21 23:59:16 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
