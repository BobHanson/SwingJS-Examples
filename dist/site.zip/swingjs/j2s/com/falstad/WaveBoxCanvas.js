(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.WaveBoxFrame',['com.falstad.WaveBoxFrame','.PinholeSetup'],['com.falstad.WaveBoxFrame','.TwoSourcesSetup'],['com.falstad.WaveBoxFrame','.DipoleSourceSetup'],['com.falstad.WaveBoxFrame','.LateralQuadrupoleSetup'],['com.falstad.WaveBoxFrame','.LinearQuadrupoleSetup'],['com.falstad.WaveBoxFrame','.TwoPinholesSetup'],['com.falstad.WaveBoxFrame','.SingleLineSetup'],['com.falstad.WaveBoxFrame','.SingleSlitSetup'],['com.falstad.WaveBoxFrame','.DoubleLineSetup'],['com.falstad.WaveBoxFrame','.DoubleSlitSetup'],['com.falstad.WaveBoxFrame','.TripleSlitSetup'],['com.falstad.WaveBoxFrame','.PlaneWaveSetup'],['com.falstad.WaveBoxFrame','.TwoPlaneWavesSetup'],'java.util.Vector',['com.falstad.WaveBoxFrame','.SingleSourceSetup'],'com.falstad.WaveBoxLayout','com.falstad.WaveBoxCanvas','java.awt.Label','java.awt.Choice','java.awt.Checkbox','java.awt.Scrollbar',['com.falstad.WaveBoxFrame','.AuxBar'],'java.util.Random','java.awt.Color','java.awt.image.MemoryImageSource','java.awt.Rectangle']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "WaveBoxCanvas", null, 'java.awt.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_WaveBoxFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateWaveBox$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.pg.updateWaveBox$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-06-10 15:13:23 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
