(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.FourierFrame','a2s.Button','a2s.Checkbox','java.util.Hashtable','java.util.StringTokenizer','java.util.Random','com.falstad.FFT','com.falstad.FourierLayout','com.falstad.FourierCanvas','a2s.Label','a2s.Scrollbar','java.awt.Color','java.text.NumberFormat',['com.falstad.FourierFrame','.View'],'java.awt.Font','com.falstad.Fourier','javajs.util.JSAudioThread','javax.sound.sampled.AudioFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FourierCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$com_falstad_FourierFrame', function (p) {
Clazz.super_(C$, this,1);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateFourier$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateFourier$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 06:44:33 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
