(function(){var P$=Clazz.newPackage("com.falstad"),I$=[[0,'java.awt.Dimension','com.falstad.QuantumStatesFrame',['com.falstad.QuantumStatesFrame','.FiniteWellSetup'],['com.falstad.QuantumStatesFrame','.HarmonicOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellPairCoupledSetup'],['com.falstad.QuantumStatesFrame','.AsymmetricWellSetup'],['com.falstad.QuantumStatesFrame','.InfiniteWellFieldSetup'],['com.falstad.QuantumStatesFrame','.WellPairCoupledFieldSetup'],['com.falstad.QuantumStatesFrame','.CoulombSetup'],['com.falstad.QuantumStatesFrame','.QuarticOscillatorSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArraySetup'],['com.falstad.QuantumStatesFrame','.HarmonicWellArraySetup'],['com.falstad.QuantumStatesFrame','.CoulombWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayFieldSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayImpureSetup'],['com.falstad.QuantumStatesFrame','.FiniteWellArrayDislocSetup'],['com.falstad.QuantumStatesFrame','.RandomWellArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWell2ArraySetup'],['com.falstad.QuantumStatesFrame','.FiniteWellCoupledArraySetup'],['com.falstad.QuantumStatesFrame','.DeltaArraySetup'],'java.util.Vector',['com.falstad.QuantumStatesFrame','.InfiniteWellSetup'],'com.falstad.QuantumStatesLayout','com.falstad.QuantumStatesCanvas','java.awt.MenuBar','java.awt.Menu','java.awt.Choice','java.awt.Button','java.awt.Checkbox','java.awt.Label','com.falstad.DecentScrollbar','java.awt.Color','java.util.Random','java.text.NumberFormat','java.awt.MenuItem','java.awt.CheckboxMenuItem','com.falstad.ButtonGroup','com.falstad.JRadioButtonMenuItem',['com.falstad.QuantumStatesFrame','.View'],'java.awt.Cursor',['com.falstad.QuantumStatesFrame','.FFT']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QuantumStatesCanvas", null, 'java.awt.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pg','com.falstad.QuantumStatesFrame']]]

Clazz.newMeth(C$, 'c$$com_falstad_QuantumStatesFrame', function (p) {
Clazz.super_(C$, this);
this.pg=p;
}, 1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return Clazz.new_($I$(1,1).c$$I$I,[300, 400]);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.pg.updateQuantumStates$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-10-22 00:01:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
